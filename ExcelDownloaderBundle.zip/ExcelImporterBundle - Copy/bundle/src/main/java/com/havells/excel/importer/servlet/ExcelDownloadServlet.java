package com.havells.excel.importer.servlet;


import java.io.IOException;
import java.rmi.ServerException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.query.Query;
import javax.jcr.query.QueryResult;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.havells.excel.importer.ExcelDownloaderConstants;
import com.havells.excel.importer.ExcelImporterConstants;
import com.havells.excel.importer.DTO.Headers;
import com.havells.excel.importer.DTO.Product;

@SlingServlet(
        label = "Excel Downloader - Sling All Methods Servlet",
        description = "Excel Downloader serlvet to parse excel file and read data.",
        paths = { "/bin/exceldownloader" },
        methods = { "GET", "POST" } // Ignored if paths is set - Defaults to GET if not specified
)
public class ExcelDownloadServlet 
	 extends SlingAllMethodsServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Reference
	private ResourceResolverFactory resolverFactory;
	
	
	protected final Logger log = LoggerFactory.getLogger(getClass());
	
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
		    throws ServerException, IOException {
		
		ResourceResolver resourceResolver=null;
		try {
			log.info("Preparing excel file");
			String range = request.getParameter("range");
			String section =request.getParameter("section");
			resourceResolver = this.resolverFactory.getAdministrativeResourceResolver(null);
			Session session = ((Session)resourceResolver.adaptTo(Session.class));
			List<Product> products = getProductNodesIterator(session,range,section);
			log.info("Preparing excel file - 2");
			//File file = new File("Demo.xlsx");
			//FileInputStream inputStream = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet("Product_Data");
			sheet.autoSizeColumn(600);
			
			log.info("Preparing excel file - 3");
			log.info("Products Size : "+products.size());
			storeValuesinExcel(sheet, products);
			log.info("Preparing excel file - 4");
			
			response.reset();
			
			response.setContentType("application/vnd.ms-excel");
			response.setHeader("Content-Disposition", "attachment; filename=\"Demo.xlsx");
			log.info("Writing excel sheet");
			log.info(response.getOutputStream()+"");;
			workbook.write(response.getOutputStream());
		} catch (LoginException e) {
			log.error("Login Exception while fetching resource resolver",e);
		} catch(Exception exception) {
			log.error("Generic Exception in doGet method",exception);
		 }
		
		
		
	}
	
	public void createExcelHeaders(XSSFSheet sheet) {
		
		Row row = sheet.createRow(0);
		
		XSSFCellStyle fontStyle = sheet.getWorkbook().createCellStyle();
		XSSFFont font = sheet.getWorkbook().createFont();
		font.setBold(true);
		fontStyle.setFont(font);
		
		
		Cell identifier=row.createCell(ExcelDownloaderConstants.SKU_IDENTIFIER);
		identifier.setCellValue("Product Identifier");
		identifier.setCellStyle(fontStyle);
		
		Cell priceCell=row.createCell(ExcelDownloaderConstants.PRICE);
		priceCell.setCellValue("Price");
		identifier.setCellStyle(fontStyle);
		
		Cell jcrTitleCell=row.createCell(ExcelDownloaderConstants.JCR_TITLE);
		jcrTitleCell.setCellValue("JCR Title");
		jcrTitleCell.setCellStyle(fontStyle);
		
		Cell subTitle=row.createCell(ExcelDownloaderConstants.SUB_TITLE);
		subTitle.setCellValue("Sub Title");
		subTitle.setCellStyle(fontStyle);
		
		Cell enableEcommCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_ENABLE_ECOMM);
		enableEcommCell.setCellValue("Enable Ecomm");
		enableEcommCell.setCellStyle(fontStyle);
		
		Cell imageNodeURLCell=row.createCell(ExcelDownloaderConstants.SKU_IMAGE_PATH);
		imageNodeURLCell.setCellValue("Image Path");
		imageNodeURLCell.setCellStyle(fontStyle);
		
		Cell productImages=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_PRODUCT_IMAGES);
		productImages.setCellValue("Product Images");
		productImages.setCellStyle(fontStyle);
		
		Cell imageCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_360_DEGREE_IMAGE);
		imageCell.setCellValue("Product 360 Degree Image");
		imageCell.setCellStyle(fontStyle);
		
		Cell cqTags=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_CQ_TAGS);
		cqTags.setCellValue("Cq Tags");
		cqTags.setCellStyle(fontStyle);
		
		Cell colorCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_COLOR);
		colorCell.setCellValue("Color");
		colorCell.setCellStyle(fontStyle);
		
		
		Cell colorImageCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_COLOR_IMG);
		colorImageCell.setCellValue("Color Image");
		colorImageCell.setCellStyle(fontStyle);
		
		Cell giftWrapCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_GIFT_WRAP);
		giftWrapCell.setCellValue("Gift Wraps");
		giftWrapCell.setCellStyle(fontStyle);
		
		Cell productManualCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_PRODUCT_MANUAL);
		productManualCell.setCellValue("Product Manual");
		productManualCell.setCellStyle(fontStyle);
		
		
		Cell productBrochureCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_PRODUCT_BROCHURE);
		productBrochureCell.setCellValue("Product Brochure");
		productBrochureCell.setCellStyle(fontStyle);
		
		Cell productRecommendation=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_PRODUCT_RECOMMENDATIONS);
		productRecommendation.setCellValue("Product Recommendation");
		productRecommendation.setCellStyle(fontStyle);
		
		
		int j=1;
		for(int i=ExcelDownloaderConstants.SKU_OTHER_INFO_QUICK_FEATURES_STARTING_INDEX;i<ExcelDownloaderConstants.SKU_OTHER_INFO_QUICK_FEATURES_ENDING_INDEX;i=i+2) {
			
			Cell quickFeatureHeading=row.createCell(i);
			quickFeatureHeading.setCellValue("Quick Feature Heading "+j);
			quickFeatureHeading.setCellStyle(fontStyle);
			
			Cell quickFeatureDescription=row.createCell(i+1);
			quickFeatureDescription.setCellValue("Quick Feature Description "+j);
			quickFeatureDescription.setCellStyle(fontStyle);
			
			j++;
		}
		
		j=1;
		for(int i=ExcelDownloaderConstants.SKU_OTHER_INFO_DETAIL_FEATURES_STARTING_INDEX;i<ExcelDownloaderConstants.SKU_OTHER_INFO_DETAIL_FEATURES_ENDING_INDEX;i=i+3) {
			
			Cell detailFeatureHeading=row.createCell(i);
			detailFeatureHeading.setCellValue("Detail Feature Heading "+j);
			detailFeatureHeading.setCellStyle(fontStyle);
			
			Cell detailFeatureDescription=row.createCell(i+1);
			detailFeatureDescription.setCellValue("Detail Feature Description "+j);
			detailFeatureDescription.setCellStyle(fontStyle);
			
			Cell detailFeatureImage=row.createCell(i+2);
			detailFeatureImage.setCellValue("Detail Feature Image "+j);
			detailFeatureImage.setCellStyle(fontStyle);
			
			j++;
		}
		
		j=1;
		for(int i=ExcelDownloaderConstants.SKU_OTHER_INFO_OPTIONAL_FEATURES_STARTING_INDEX;i<ExcelDownloaderConstants.SKU_OTHER_INFO_OPTIONAL_FEATURES_ENDING_INDEX;i=i+3) {
			
			Cell optionalFeatureHeading=row.createCell(i);
			optionalFeatureHeading.setCellValue("Optiional Feature Heading "+j);
			optionalFeatureHeading.setCellStyle(fontStyle);
			
			Cell optionalFeatureDescription=row.createCell(i+1);
			optionalFeatureDescription.setCellValue("Optiional Feature Description "+j);
			optionalFeatureDescription.setCellStyle(fontStyle);
			
			Cell optionalFeatureImage=row.createCell(i+2);
			optionalFeatureImage.setCellValue("Optiional Feature Image "+j);
			optionalFeatureImage.setCellStyle(fontStyle);
			
			j++;
		}
		
		Cell faqCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_FAQ);
		faqCell.setCellValue("Faq");
		faqCell.setCellStyle(fontStyle);
		
		j=1;
		for(int i=ExcelDownloaderConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_STARTING_INDEX;i<ExcelDownloaderConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_ENDING_INDEX;i=i+3) {
			
			Cell technicalSpecTags=row.createCell(i);
			technicalSpecTags.setCellValue("Technical Spec Cq Tags "+j);
			technicalSpecTags.setCellStyle(fontStyle);
			
			Cell technicalSpecKey=row.createCell(i+1);
			technicalSpecKey.setCellValue("Technical Spec Key "+j);
			technicalSpecKey.setCellStyle(fontStyle);
			
			Cell technicalSpecValue=row.createCell(i+2);
			technicalSpecValue.setCellValue("Technical Spec Value "+j);
			technicalSpecValue.setCellStyle(fontStyle);
			
			j++;
		}
		
		Cell technicalSpecImageProperty=row.createCell(ExcelDownloaderConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_IMAGE_PROPERTY);
		technicalSpecImageProperty.setCellValue("Technical Spec Image Property");
		technicalSpecImageProperty.setCellStyle(fontStyle);
		
		j=1;
		for(int i=ExcelDownloaderConstants.SKU_OTHER_INFO_ACCESSORY_STARTING_INDEX;i<ExcelDownloaderConstants.SKU_OTHER_INFO_ACCESSORY_ENDING_INDEX;i=i+3) {
			
			Cell accessoryHeading=row.createCell(i);
			accessoryHeading.setCellValue("Accessory Heading "+j);
			accessoryHeading.setCellStyle(fontStyle);
			
			Cell accessoryDescription=row.createCell(i+1);
			accessoryDescription.setCellValue("Accessory Description "+j);
			accessoryDescription.setCellStyle(fontStyle);
			
			Cell accessoryImage=row.createCell(i+2);
			accessoryImage.setCellValue("Accessory Image "+j);
			accessoryImage.setCellStyle(fontStyle);
			
			j++;
		}
		
		Cell technicalDrawingImages=row.createCell(ExcelDownloaderConstants.SKU_OTHER_INFO_TECHNICAL_DRAWING_IMAGES);
		technicalDrawingImages.setCellValue("Technical Drawing Images");
		technicalDrawingImages.setCellStyle(fontStyle);
		
		Cell youTubeURLs=row.createCell(ExcelDownloaderConstants.SKU_OTHER_INFO_YOU_TUBE_URLS);
		youTubeURLs.setCellValue("You Tube URLs");
		youTubeURLs.setCellStyle(fontStyle);
		
		
	}
	public void storeValuesinExcel(XSSFSheet sheet , List<Product> products) {
		createExcelHeaders(sheet);
		
		for(int i=0; i<products.size();i++) {
			
			Product product = products.get(i);
			Row row = sheet.createRow(i+1);
			
			if(product.getIdentifier() != null) {
				Cell identifier=row.createCell(ExcelDownloaderConstants.SKU_IDENTIFIER);
				identifier.setCellValue(product.getIdentifier());
			}
			
			if(product.getPrice() != null) {
				Cell priceCell=row.createCell(ExcelDownloaderConstants.PRICE);
				priceCell.setCellValue(product.getPrice());
			}
			
			if(product.getJcrTitle() != null) {
				Cell jcrTitleCell=row.createCell(ExcelDownloaderConstants.JCR_TITLE);
				jcrTitleCell.setCellValue(product.getJcrTitle());
			}
			
			if(product.getSubTitles() != null) {
				Cell subTitle=row.createCell(ExcelDownloaderConstants.SUB_TITLE);
				String subTitles = "";
				String[] subTitleValues = product.getSubTitles();
				
				for(String v : subTitleValues) {
					subTitles+=v+", ";
				}
				if(!subTitles.equals("")) {
					subTitles.substring(0,subTitles.lastIndexOf(","));
				}
				
				subTitle.setCellValue(subTitles);
				
			}
		
			if(product.getEnableEcomm() != null) {
				Cell enableEcommCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_ENABLE_ECOMM);
				enableEcommCell.setCellValue(product.getEnableEcomm());
			}
			
			if(product.getImageNodeURL() != null) {
				Cell imageNodeURLCell=row.createCell(ExcelDownloaderConstants.SKU_IMAGE_PATH);
				imageNodeURLCell.setCellValue(product.getImageNodeURL());
			}
			
			if(product.getProductImages() != null) {
				Cell productImages=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_PRODUCT_IMAGES);
				
				String productImagesString = "";
				String[] productImagesArray = product.getProductImages();
				
				for(String v : productImagesArray) {
					productImagesString+=v+", ";
				}
				if(!productImagesString.equals("")) {
					productImagesString.substring(0,productImagesString.lastIndexOf(","));
				}
				
				productImages.setCellValue(productImagesString);
			}
			
			if(product.getImageNodeURL() != null) {
				Cell imageCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_360_DEGREE_IMAGE);
				imageCell.setCellValue(product.getImageNodeURL());
			}
			
			if(product.getCqTags() != null) {
				Cell cqTags=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_CQ_TAGS);
				String cqTag = "";
				String[] cqTagsValues = product.getCqTags();
				 for(String v : cqTagsValues) {
					 cqTag+=v+", ";
				 }
				 if(!cqTag.equals("")) {
					 cqTag.substring(0,cqTag.lastIndexOf(","));
				 }
				 
				cqTags.setCellValue(cqTag);
			}
			
			if(product.getColor() != null) {
				Cell colorCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_COLOR);
				colorCell.setCellValue(product.getColor());
			}
			
			if(product.getColorImage() != null) {
				Cell colorImageCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_COLOR_IMG);
				colorImageCell.setCellValue(product.getColorImage());
			}
		
			if(product.getGiftWrap() != null) {
				Cell giftWrapCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_GIFT_WRAP);
				giftWrapCell.setCellValue(product.getGiftWrap());
			}
			
			if(product.getProductManual() != null) {
				Cell productManualCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_PRODUCT_MANUAL);
				productManualCell.setCellValue(product.getProductManual());
			}
			
			if(product.getProductBrochure() != null ) {
				Cell productBrochureCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_PRODUCT_BROCHURE);
				productBrochureCell.setCellValue(product.getProductBrochure());
			}
			
			if(product.getProductRecommendations() != null) {
				Cell productRecommendation=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_PRODUCT_RECOMMENDATIONS);
				String productRecommendationString = "";
				String[] productRecommendationArray = product.getProductRecommendations();
				
				for(String v : productRecommendationArray) {
					productRecommendationString+=v+", ";
				}
				if(!productRecommendationString.equals("")) {
					productRecommendationString.substring(0,productRecommendationString.lastIndexOf(","));
				}
				productRecommendation.setCellValue(productRecommendationString);
			}
			
			if(product.getQuickFeaturesHeaders() != null || product.getQuickFeaturesDescriptions() != null) {
					String[] quickFeatureHeaders = product.getQuickFeaturesHeaders();
					String[] quickFeatureDescriptions = product.getQuickFeaturesDescriptions();
							
					int j=0;
					for(int k=ExcelDownloaderConstants.SKU_OTHER_INFO_QUICK_FEATURES_STARTING_INDEX;k<ExcelDownloaderConstants.SKU_OTHER_INFO_QUICK_FEATURES_ENDING_INDEX;k=k+2) {
						
						if(quickFeatureHeaders != null && quickFeatureHeaders[j] != null) {
							Cell quickFeatureHeading=row.createCell(k);
							quickFeatureHeading.setCellValue(quickFeatureHeaders[j]);
						}
						if(quickFeatureDescriptions != null && quickFeatureDescriptions[j] != null) {
							Cell quickFeatureDescription=row.createCell(k+1);
							quickFeatureDescription.setCellValue(quickFeatureDescriptions[j]);
						}
						j++;
					}
			}
			
			if(product.getOptionalFeaturesHeaders() != null || product.getOptionalFeaturesDesciptions() != null || product.getOptionalFeaturesImages() != null) {
				String[] optionalFeatureHeaders = product.getOptionalFeaturesHeaders();
				String[] optionalFeatureDescriptions = product.getOptionalFeaturesDesciptions();
				String[] optionalFeatureImages = product.getOptionalFeaturesImages();
						
				int j=0;
				for(int k=ExcelDownloaderConstants.SKU_OTHER_INFO_OPTIONAL_FEATURES_STARTING_INDEX;k<ExcelDownloaderConstants.SKU_OTHER_INFO_OPTIONAL_FEATURES_ENDING_INDEX;k=k+3) {
					
					if(optionalFeatureHeaders != null && optionalFeatureHeaders[j] != null) {
						Cell optionalFeatureHeading=row.createCell(k);
						optionalFeatureHeading.setCellValue(optionalFeatureHeaders[j]);
					}
					if(optionalFeatureDescriptions != null && optionalFeatureDescriptions[j] != null) {
						Cell quickFeatureDescription=row.createCell(k+1);
						quickFeatureDescription.setCellValue(optionalFeatureDescriptions[j]);
					}
					if(optionalFeatureImages != null && optionalFeatureImages[j] != null) {
						Cell optionalFeatureImage=row.createCell(k+2);
						optionalFeatureImage.setCellValue(optionalFeatureImages[j]);
					}
					j++;
				}
		    }
			
			if(product.getDetailFeaturesHeaders() != null || product.getDetailFeaturesDesciptions() != null || product.getDetailFeaturesImages() != null) {
				String[] detailFeatureHeaders = product.getDetailFeaturesHeaders();
				log.info("Detail Feature Header Size"+detailFeatureHeaders.length);
				String[] detailFeatureDescriptions = product.getDetailFeaturesHeaders();
				log.info("Detail Feature Description Size"+detailFeatureDescriptions.length);
				String[] detailFeatureImages = product.getDetailFeaturesImages();
						
				int j=0;
				for(int k=ExcelDownloaderConstants.SKU_OTHER_INFO_DETAIL_FEATURES_STARTING_INDEX;k<ExcelDownloaderConstants.SKU_OTHER_INFO_DETAIL_FEATURES_ENDING_INDEX;k=k+3) {
					
					if(detailFeatureHeaders != null && detailFeatureHeaders[j] != null) {
						Cell detailFeatureHeading=row.createCell(k);
						detailFeatureHeading.setCellValue(detailFeatureHeaders[j]);
					}
					if(detailFeatureDescriptions != null && detailFeatureDescriptions[j] != null) {
						Cell detailFeatureDescription=row.createCell(k+1);
						detailFeatureDescription.setCellValue(detailFeatureDescriptions[j]);
					}
					if(detailFeatureImages != null && detailFeatureImages[j] != null) {
						Cell detailFeatureImage=row.createCell(k+2);
						detailFeatureImage.setCellValue(detailFeatureImages[j]);
					}
					j++;
				}
		    }
			
			
			if(product.getFaq() != null) {
				Cell faqCell=row.createCell(ExcelDownloaderConstants.SKU_PROPERTY_FAQ);
				faqCell.setCellValue(product.getFaq());
			}
			
			if(product.getTechnicalSpecHeaders() != null && product.getTechnicalSpecHeaders().size() > 0) { 
				List<Headers> headers = product.getTechnicalSpecHeaders();
				
				int j=0;
				for(int k=ExcelDownloaderConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_STARTING_INDEX;k<ExcelDownloaderConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_ENDING_INDEX;k=k+3) {
					Headers header = headers.get(j);
					
					if(header != null) {
						Cell technicalSpecTags=row.createCell(k);
						technicalSpecTags.setCellValue(header.getCqTag());
						
						Cell technicalSpecKey=row.createCell(k+1);
						technicalSpecKey.setCellValue(header.getKey());
						
						Cell technicalSpecValue=row.createCell(k+2);
						technicalSpecValue.setCellValue(header.getValue());
					} else {
						break;
					}
					j++;
				}
			}
			
			if(product.getTechnicalSpecImages() != null) {
				Cell technicalSpecImageProperty=row.createCell(ExcelDownloaderConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_IMAGE_PROPERTY);
				
				String technicalSpecImages = "";
				String[] technicalSpecImageArray = product.getTechnicalSpecImages();
				
				for(String v : technicalSpecImageArray) {
					technicalSpecImages+=v+", ";
				}
				if(!technicalSpecImages.equals("")) {
					technicalSpecImages.substring(0,technicalSpecImages.lastIndexOf(","));
				}
				technicalSpecImageProperty.setCellValue(technicalSpecImages);
			}
			
			if(product.getAccessoryHeaders() != null || product.getAccessoryDesciptions() != null || product.getAccessoryImages() != null) {
				String[] accessoryHeaders = product.getAccessoryHeaders();
				String[] accessoryDescriptions = product.getAccessoryDesciptions();
				String[] accessoryImages = product.getAccessoryImages();
						
				int j=0;
				for(int k=ExcelDownloaderConstants.SKU_OTHER_INFO_ACCESSORY_STARTING_INDEX;k<ExcelDownloaderConstants.SKU_OTHER_INFO_ACCESSORY_ENDING_INDEX;k=k+3) {
					
					if(accessoryHeaders != null && accessoryHeaders[j] != null) {
						Cell accessoryHeading=row.createCell(k);
						accessoryHeading.setCellValue(accessoryHeaders[j]);
					}
					if(accessoryDescriptions != null && accessoryDescriptions[j] != null) {
						Cell accessoryDescription=row.createCell(k+1);
						accessoryDescription.setCellValue(accessoryDescriptions[j]);
					}
					if(accessoryImages != null && accessoryImages[j] != null) {
						Cell accessoryImage=row.createCell(k+2);
						accessoryImage.setCellValue(accessoryImages[j]);
					}
					j++;
				}
		    }
			
			if(product.getTechnicalDrawingImages() != null) {
				Cell technicalDrawingImages=row.createCell(ExcelDownloaderConstants.SKU_OTHER_INFO_TECHNICAL_DRAWING_IMAGES);
				
				String technicalDrawingImageString = "";
				String[] technicalDrawingImageArray = product.getTechnicalDrawingImages();
				
				for(String v : technicalDrawingImageArray) {
					technicalDrawingImageString+=v+", ";
				}
				if(!technicalDrawingImageString.equals("")) {
					technicalDrawingImageString.substring(0,technicalDrawingImageString.lastIndexOf(","));
				}
				
				technicalDrawingImages.setCellValue(technicalDrawingImageString);
			}
			
			if(product.getYouTubeURLS() != null) {
				Cell youTubeURLs=row.createCell(ExcelDownloaderConstants.SKU_OTHER_INFO_YOU_TUBE_URLS);
				
				String youTubeURLString = "";
				String[] youTubeURLSArray= product.getYouTubeURLS();
				
				for(String v : youTubeURLSArray) {
					youTubeURLString+=v+", ";
				}
				if(!youTubeURLString.equals("")) {
					youTubeURLString.substring(0,youTubeURLString.lastIndexOf(","));
				}
				
				youTubeURLs.setCellValue(youTubeURLString);
			}
		}
		
		
	}
	 public List<Product> getProductNodesIterator(Session session, String range, String section) {
		    
	    	String queryString = "SELECT * FROM [nt:unstructured] AS node WHERE ISDESCENDANTNODE(node, '/etc/commerce/products/havells/"+range+"/"+section+"') AND node.[sling:resourceType] LIKE 'commerce/components/product'";
	 	    
	    	log.info("Query String: "+queryString);
	 	    Query query=null;
    	 	List<Product> products = null;
	 	    
				try {
					query = session.getWorkspace().getQueryManager().createQuery(queryString,Query.JCR_SQL2);
					QueryResult results = query.execute();
					
					if(results != null) {
						products = new ArrayList<Product>();
						NodeIterator nodes = results.getNodes();
						while(nodes.hasNext()) {
							Node node = nodes.nextNode();
							products.add(getProductObjectFromNode(node));
						}
					}
				} catch (Exception exception) {
					log.error("Exception while storing information in product node." + exception);
				}
				return products;
	    }
	 
	 public Product getProductObjectFromNode(Node productNode) {
		 Product product = null;
		 try {
			 if(productNode != null) {
				 
				 product = new Product();
				 
				 if(productNode.hasProperty("backgroundImg")) {
					 product.setBackgroungImage(productNode.getProperty("backgroundImg").getString());
				 }
				 if(productNode.hasProperty("price")) {
					 product.setPrice(productNode.getProperty("price").getString());
				 }
				 if(productNode.hasProperty("identifier")) {
					 product.setIdentifier(productNode.getProperty("identifier").getString());
				 }
				 if(productNode.hasProperty("color")) {
					 product.setColor(productNode.getProperty("color").getString());
				 }
				 if(productNode.hasProperty("cqTags")) {
					 Value[] values = productNode.getProperty("cqTags").getValues();
					 String[] cqTags = new String[values.length];
					 for(int i=0;i<values.length;i++) {
						 cqTags[i]=values[i].getString();
					 }
					 product.setCqTags(cqTags);
				 }
				 if(productNode.hasProperty("damVideo")) {
					 product.setDamVideo(productNode.getProperty("damVideo").getString());
				 }
				 if(productNode.hasProperty("enableEcomm")) {
					 product.setEnableEcomm(productNode.getProperty("enableEcomm").getString());
				 }
				 if(productNode.hasProperty("faq")) {
					 product.setFaq(productNode.getProperty("faq").getString());
				 }
				 if(productNode.hasProperty("giftWrap")) {
					 product.setGiftWrap(productNode.getProperty("giftWrap").getString());
				 }
				 if(productNode.hasProperty("jcr:title")) {
					 product.setJcrTitle(productNode.getProperty("jcr:title").getString());
				 }
				 if(productNode.hasProperty("pagePath")) {
					 product.setPagePath(productNode.getProperty("pagePath").getString());
				 }
				 if(productNode.hasProperty("productBrochure")) {
					 product.setProductBrochure(productNode.getProperty("productBrochure").getString());
				 }
				 if(productNode.hasProperty("productManual")) {
					 product.setProductManual(productNode.getProperty("productManual").getString());
				 }
				 if(productNode.hasProperty("productRecommendation")) {
					 Value[] values = productNode.getProperty("productRecommendation").getValues();
					 String[] productRecommendation = new String[values.length];
					 for(int i=0;i<values.length;i++) {
						 productRecommendation[i]=values[i].getString();
					 }
					 product.setProductRecommendations(productRecommendation);
				 }
				 if(productNode.hasProperty("productImages")) {
					 Value[] values = productNode.getProperty("productImages").getValues();
					 String[] productImages = new String[values.length];
					 for(int i=0;i<values.length;i++) {
						 productImages[i]=values[i].getString();
					 }
					 product.setProductImages(productImages);
				 }
				 if(productNode.hasProperty("subTitle")) {
					 String[] subTitles = {productNode.getProperty("subTitle").getString()};
					 product.setSubTitles(subTitles);
				 }
				 if(productNode.hasProperty("title")) {
					 product.setTitle(productNode.getProperty("title").getString());
				 }
				 if(productNode.hasProperty("youtube")) {
					 Value[] values = productNode.getProperty("youtube").getValues();
					 String[] youTubeURLS = new String[values.length];
					 for(int i=0;i<values.length;i++) {
						 youTubeURLS[i]=values[i].getString();
					 }
					 product.setYouTubeURLS(youTubeURLS);
				 }
				 
				 if(productNode.hasNode("otherInfo")) {
					Node otherInfoNode = productNode.getNode("otherInfo"); 
					if(otherInfoNode.hasNode(ExcelDownloaderConstants.QUICK_FEATURES_NODE)) {
						 Node quickFeaturesNode = otherInfoNode.getNode(ExcelImporterConstants.QUICK_FEATURES_NODE);
						 String[] quickFeatureHeaders = new String[4];
						 String[] quickFeatureDescription = new String[4];
						 for(int i=1; i<= 4; i++) {
							 
							 if(quickFeaturesNode.hasProperty(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i)) {
								 quickFeatureHeaders[i-1] = quickFeaturesNode.getProperty(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i).getString();
							 }
							 if(quickFeaturesNode.hasProperty(ExcelDownloaderConstants.DESCRIPTION_PROPERTY_PREFIX+i)) {
								 quickFeatureDescription[i-1] = quickFeaturesNode.getProperty(ExcelDownloaderConstants.DESCRIPTION_PROPERTY_PREFIX+i).getString();
							 }
						 }
						 product.setQuickFeaturesHeaders(quickFeatureHeaders);
						 product.setQuickFeaturesDescriptions(quickFeatureDescription);
					 }
					
					if(otherInfoNode.hasNode(ExcelDownloaderConstants.DETAIL_FEATURES_NODE)) {
						 Node detailFeatureNode = otherInfoNode.getNode(ExcelImporterConstants.DETAIL_FEATURES_NODE);
						 String[] detailFeatureHeaders = new String[25];
						 String[] detailFeatureDescription = new String[25];
						 String[] detailFeatureImages = new String[25];
						 for(int i=1; i<= 25; i++) {
							 
							 if(detailFeatureNode.hasProperty(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i)) {
								 detailFeatureHeaders[i-1] = detailFeatureNode.getProperty(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i).getString();
							 }
							 if(detailFeatureNode.hasProperty(ExcelDownloaderConstants.DESCRIPTION_PROPERTY_PREFIX+i)) {
								 detailFeatureDescription[i-1] = detailFeatureNode.getProperty(ExcelDownloaderConstants.DESCRIPTION_PROPERTY_PREFIX+i).getString();
							 }
							 if(detailFeatureNode.hasProperty(ExcelDownloaderConstants.IMAGE_PROPERTY_PREFIX+i)) {
								 detailFeatureImages[i-1] = detailFeatureNode.getProperty(ExcelDownloaderConstants.IMAGE_PROPERTY_PREFIX+i).getString();
							 }
						 }
						 product.setDetailFeaturesHeaders(detailFeatureHeaders);
						 product.setDetailFeaturesDesciptions(detailFeatureDescription);
						 product.setDetailFeaturesImages(detailFeatureImages);
							
					}
					
					if(otherInfoNode.hasNode(ExcelDownloaderConstants.OPTIONAL_FEATURES_NODE)) {
						 Node optionalFeatureNode = otherInfoNode.getNode(ExcelImporterConstants.OPTIONAL_FEATURES_NODE);
						 String[] optionalFeatureHeaders = new String[25];
						 String[] optionalFeatureDescription = new String[25];
						 String[] optionalFeatureImages = new String[25];
						 for(int i=1; i<= 25; i++) {
							 
							 if(optionalFeatureNode.hasProperty(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i)) {
								 optionalFeatureHeaders[i-1] = optionalFeatureNode.getProperty(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i).getString();
							 }
							 if(optionalFeatureNode.hasProperty(ExcelDownloaderConstants.DESCRIPTION_PROPERTY_PREFIX+i)) {
								 optionalFeatureDescription[i-1] = optionalFeatureNode.getProperty(ExcelDownloaderConstants.DESCRIPTION_PROPERTY_PREFIX+i).getString();
							 }
							 if(optionalFeatureNode.hasProperty(ExcelDownloaderConstants.IMAGE_PROPERTY_PREFIX+i)) {
								 optionalFeatureImages[i-1] = optionalFeatureNode.getProperty(ExcelDownloaderConstants.IMAGE_PROPERTY_PREFIX+i).getString();
							 }
						 }
						 product.setOptionalFeaturesHeaders(optionalFeatureHeaders);
						 product.setOptionalFeaturesDesciptions(optionalFeatureDescription);
						 product.setOptionalFeaturesImages(optionalFeatureImages);
							
					}
					
					if(otherInfoNode.hasNode(ExcelDownloaderConstants.TECHNICAL_SPEC_NODE)) {
						 Node technicalSpecNode = otherInfoNode.getNode(ExcelImporterConstants.OPTIONAL_FEATURES_NODE);
						 List<Headers> technicalSpecHeaders = new ArrayList<Headers>();
						
						 for(int i=1; i<= 65; i++) {
							 if(technicalSpecNode.hasNode(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i)) {
								 Node heading = technicalSpecNode.getNode(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i);
								 Headers header = new Headers();
								 if(heading.hasProperty(ExcelDownloaderConstants.CQ_TAGS_PROPERTY)) {
									 String cqTag = "";
									 Value[] cqTags = heading.getProperty(ExcelDownloaderConstants.CQ_TAGS_PROPERTY).getValues();
									 for(Value v : cqTags) {
										 cqTag+=v+", ";
									 }
									 if(!cqTag.equals("")) {
										 cqTag.substring(0,cqTag.lastIndexOf(","));
									 }
									 header.setCqTag(cqTag);
								 }
								 if(heading.hasProperty(ExcelDownloaderConstants.KEY_PROPERTY)) {
									 header.setValue(heading.getProperty(ExcelDownloaderConstants.KEY_PROPERTY).getString());
								 }
								 if(heading.hasProperty(ExcelDownloaderConstants.VALUE_PROPERTY)) {
									 header.setKey(heading.getProperty(ExcelDownloaderConstants.VALUE_PROPERTY).getString());
								 }
								 technicalSpecHeaders.add(header);
							 }
						 }
						 product.setTechnicalSpecHeaders(technicalSpecHeaders);
						 if(technicalSpecNode.hasProperty("images")) {
							 
							 String[] imageArray = {};
							 Value[] imagesValue = technicalSpecNode.getProperty("images").getValues();
							 for(int i=0;i<imagesValue.length;i++) {
								 imageArray[i]=imagesValue[i].getString();
							 }
							 product.setTechnicalSpecImages(imageArray);
						 }
					}

					if(otherInfoNode.hasNode(ExcelDownloaderConstants.ACCESSORY_NODE)) {
						 Node accessoryNodes = otherInfoNode.getNode(ExcelImporterConstants.ACCESSORY_NODE);
						 String[] accessoryHeaders = new String[20];
						 String[] accessoryDescription = new String[20];
						 String[] accessoryImages = new String[20];
						 for(int i=1; i<= 20; i++) {
							 
							 if(accessoryNodes.hasProperty(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i)) {
								 accessoryHeaders[i-1] = accessoryNodes.getProperty(ExcelDownloaderConstants.HEADER_PROPERTY_PREFIX+i).getString();
							 }
							 if(accessoryNodes.hasProperty(ExcelDownloaderConstants.DESCRIPTION_PROPERTY_PREFIX+i)) {
								 accessoryDescription[i-1] = accessoryNodes.getProperty(ExcelDownloaderConstants.DESCRIPTION_PROPERTY_PREFIX+i).getString();
							 }
							 if(accessoryNodes.hasProperty(ExcelDownloaderConstants.IMAGE_PROPERTY_PREFIX+i)) {
								 accessoryImages[i-1] = accessoryNodes.getProperty(ExcelDownloaderConstants.IMAGE_PROPERTY_PREFIX+i).getString();
							 }
						 }
						 product.setAccessoryHeaders(accessoryHeaders);
						 product.setAccessoryDesciptions(accessoryDescription);
						 product.setAccessoryImages(accessoryImages);
							
					}
					
					if(otherInfoNode.hasNode(ExcelDownloaderConstants.TECHNICAL_DRAWING_IMAGES)) {
						Node technicalDrawingNode = otherInfoNode.getNode(ExcelDownloaderConstants.TECHNICAL_DRAWING_IMAGES);
						if(technicalDrawingNode.hasProperty(ExcelDownloaderConstants.DRAWING_IMAGES_PROPERTY)) {
							 String[] imageArray = {};
							 Value[] imagesValue = technicalDrawingNode.getProperty(ExcelDownloaderConstants.DRAWING_IMAGES_PROPERTY).getValues();
							 for(int i=0;i<imagesValue.length;i++) {
								 imageArray[i]=imagesValue[i].getString();
							 }
							 product.setTechnicalDrawingImages(imageArray);
						}
					}
					
				 }
			 }
		 } catch(Exception exception) {
			 log.error("Generic Exception"+exception);
		 }
		 return product;
	 }
	 
	 public String[] convertObjectToStringArray(Object[] array) {
		 String[] stringArray = null;
		 if(array != null ) {
			 stringArray = new String[array.length];
			 for(int i=0;i<stringArray.length;i++) {
				 stringArray[i] = (String) array[i];
			 }
		 }
	     return stringArray;
	}
}
