package com.havells.excel.importer.DTO;

import java.util.List;



public class Product {

	private String identifier;
	
	private String backgroungImage;
	
	private String color;
	
	private String damVideo;
	
	private String colorImage;
	
	private String[] cqTags;
	
	private String enableEcomm;
	
	private String faq;
	
	private String giftWrap;
	
	private String jcrTitle;
	
	private String pagePath;
	
	private String price;
	
	private String productBrochure;
	
	private String[] productImages;
	
	private String productManual;
	
	private String[] productRecommendations;
	
	private String[] subTitles;
	
	private String title;
	
	private String[] youTubeURLS;
	
	private String imageNodeURL;
	
	private String[] quickFeaturesHeaders;
	
	private String[] quickFeaturesDescriptions;
	
	private String[] detailFeaturesHeaders;
	
	private String[] detailFeaturesDesciptions;
	
	private String[] detailFeaturesImages;
	
	private String[] optionalFeaturesHeaders;
	
	private String[] optionalFeaturesDesciptions;
	
	private String[] optionalFeaturesImages;
	
	public String[] getOptionalFeaturesHeaders() {
		return optionalFeaturesHeaders;
	}

	public void setOptionalFeaturesHeaders(String[] optionalFeaturesHeaders) {
		this.optionalFeaturesHeaders = optionalFeaturesHeaders;
	}

	public String[] getOptionalFeaturesDesciptions() {
		return optionalFeaturesDesciptions;
	}

	public void setOptionalFeaturesDesciptions(String[] optionalFeaturesDesciptions) {
		this.optionalFeaturesDesciptions = optionalFeaturesDesciptions;
	}

	public String[] getOptionalFeaturesImages() {
		return optionalFeaturesImages;
	}

	public void setOptionalFeaturesImages(String[] optionalFeaturesImages) {
		this.optionalFeaturesImages = optionalFeaturesImages;
	}

	private List<Headers> technicalSpecHeaders;
	
	private String[] technicalSpecImages;
	
	private String[] accessoryHeaders;
	
	private String[] accessoryDesciptions;
	
	private String[] accessoryImages;
	
	private String[] technicalDrawingImages;
	
	
	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getBackgroungImage() {
		return backgroungImage;
	}

	public void setBackgroungImage(String backgroungImage) {
		this.backgroungImage = backgroungImage;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getColorImage() {
		return colorImage;
	}

	public void setColorImage(String colorImage) {
		this.colorImage = colorImage;
	}

	public String[] getCqTags() {
		return cqTags;
	}

	public void setCqTags(String[] cqTags) {
		this.cqTags = cqTags;
	}

	public String getEnableEcomm() {
		return enableEcomm;
	}

	public void setEnableEcomm(String enableEcomm) {
		this.enableEcomm = enableEcomm;
	}

	public String getFaq() {
		return faq;
	}

	public void setFaq(String faq) {
		this.faq = faq;
	}

	public String getGiftWrap() {
		return giftWrap;
	}

	public void setGiftWrap(String giftWrap) {
		this.giftWrap = giftWrap;
	}

	public String getJcrTitle() {
		return jcrTitle;
	}

	public void setJcrTitle(String jcrTitle) {
		this.jcrTitle = jcrTitle;
	}

	public String getPagePath() {
		return pagePath;
	}

	public void setPagePath(String pagePath) {
		this.pagePath = pagePath;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getProductBrochure() {
		return productBrochure;
	}

	public void setProductBrochure(String productBrochure) {
		this.productBrochure = productBrochure;
	}

	public String[] getProductImages() {
		return productImages;
	}

	public void setProductImages(String[] productImages) {
		this.productImages = productImages;
	}

	public String getProductManual() {
		return productManual;
	}

	public void setProductManual(String productManual) {
		this.productManual = productManual;
	}

	public String[] getProductRecommendations() {
		return productRecommendations;
	}

	public void setProductRecommendations(String[] productRecommendations) {
		this.productRecommendations = productRecommendations;
	}

	public String[] getSubTitles() {
		return subTitles;
	}

	public void setSubTitles(String[] subTitles) {
		this.subTitles = subTitles;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String[] getYouTubeURLS() {
		return youTubeURLS;
	}

	public void setYouTubeURLS(String[] youTubeURLS) {
		this.youTubeURLS = youTubeURLS;
	}

	public String getImageNodeURL() {
		return imageNodeURL;
	}

	public void setImageNodeURL(String imageNodeURL) {
		this.imageNodeURL = imageNodeURL;
	}

	public String[] getQuickFeaturesHeaders() {
		return quickFeaturesHeaders;
	}

	public void setQuickFeaturesHeaders(String[] quickFeaturesHeaders) {
		this.quickFeaturesHeaders = quickFeaturesHeaders;
	}

	public String[] getQuickFeaturesDescriptions() {
		return quickFeaturesDescriptions;
	}

	public void setQuickFeaturesDescriptions(String[] quickFeaturesDescriptions) {
		this.quickFeaturesDescriptions = quickFeaturesDescriptions;
	}

	public String[] getDetailFeaturesHeaders() {
		return detailFeaturesHeaders;
	}

	public void setDetailFeaturesHeaders(String[] detailFeaturesHeaders) {
		this.detailFeaturesHeaders = detailFeaturesHeaders;
	}

	public String[] getDetailFeaturesDesciptions() {
		return detailFeaturesDesciptions;
	}

	public void setDetailFeaturesDesciptions(String[] detailFeaturesDesciptions) {
		this.detailFeaturesDesciptions = detailFeaturesDesciptions;
	}

	public String[] getDetailFeaturesImages() {
		return detailFeaturesImages;
	}

	public void setDetailFeaturesImages(String[] detailFeaturesImages) {
		this.detailFeaturesImages = detailFeaturesImages;
	}

	

	public String[] getTechnicalSpecImages() {
		return technicalSpecImages;
	}

	public void setTechnicalSpecImages(String[] technicalSpecImages) {
		this.technicalSpecImages = technicalSpecImages;
	}

	public String[] getAccessoryHeaders() {
		return accessoryHeaders;
	}

	public void setAccessoryHeaders(String[] accessoryHeaders) {
		this.accessoryHeaders = accessoryHeaders;
	}

	public String[] getAccessoryDesciptions() {
		return accessoryDesciptions;
	}

	public void setAccessoryDesciptions(String[] accessoryDesciptions) {
		this.accessoryDesciptions = accessoryDesciptions;
	}

	public String[] getAccessoryImages() {
		return accessoryImages;
	}

	public void setAccessoryImages(String[] accessoryImages) {
		this.accessoryImages = accessoryImages;
	}

	public String[] getTechnicalDrawingImages() {
		return technicalDrawingImages;
	}

	public void setTechnicalDrawingImages(String[] technicalDrawingImages) {
		this.technicalDrawingImages = technicalDrawingImages;
	}

	public List<Headers> getTechnicalSpecHeaders() {
		return technicalSpecHeaders;
	}

	public void setTechnicalSpecHeaders(List<Headers> technicalSpecHeaders) {
		this.technicalSpecHeaders = technicalSpecHeaders;
	}

	public String getDamVideo() {
		return damVideo;
	}

	public void setDamVideo(String damVideo) {
		this.damVideo = damVideo;
	}


	
	
	
	
}
