package com.havells.excel.importer.servlet;


import java.io.IOException;
import java.io.InputStream;
import java.rmi.ServerException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.jcr.ItemExistsException;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.version.VersionException;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.havells.excel.importer.ExcelImporterConstants;
import com.havells.excel.importer.DTO.Category;
import com.havells.excel.importer.DTO.Headers;
import com.havells.excel.importer.DTO.Product;
import com.havells.excel.importer.DTO.Range;
import com.havells.excel.importer.DTO.Section;
import com.havells.excel.importer.DTO.SubCategory;
import com.havells.excel.importer.service.ExcelImporterService;

@SlingServlet(
        label = "Excel Importer - Sling All Methods Servlet",
        description = "Excel Importer serlvet to parse excel file and read data.",
        paths = { "/bin/excelimporter" },
        methods = { "GET", "POST" } // Ignored if paths is set - Defaults to GET if not specified
)
public class ExcelImporterServlet
  extends SlingAllMethodsServlet
{
  private static final long serialVersionUID = 2598426539166789515L;
  
  @Reference
  private ResourceResolverFactory resolverFactory;
  
  private Session session;
  protected final Logger log = LoggerFactory.getLogger(getClass());
  
  @Reference
  private ExcelImporterService excelImporterService;
  
  protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
    throws ServerException, IOException
  {}
  
  protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
  {
	  try {
	      boolean isMultipart = ServletFileUpload.isMultipartContent(request);
	     
	      this.log.info("ExcelImporterService : doPost Method Called ");
	     
	      if (isMultipart)
	      {
	        Map<String, RequestParameter[]> params = request.getRequestParameterMap();
	        for (Map.Entry<String, RequestParameter[]> pairs : params.entrySet())
	        {
	          RequestParameter[] pArr = (RequestParameter[])pairs.getValue();
	          RequestParameter param = pArr[0];
	         
	          if(param != null) {
	        	  
	        	  InputStream stream = param.getInputStream();
	        	  this.log.info("ExcelImporterService : Excel spread sheet detected");
	        	  int excelValue = injectSpreadSheet(stream);
	          
	        	  if (excelValue == 0) {
	        		  this.log("ExcelImporterService : Product data from the Excel Spread Sheet has been successfully imported into the AEM JCR");
	        	  } else {
	        		  this.log("ExcelImporterService : Not able to import Product Data");
	        	  }
	          } else {
	        	  this.log.info("ExcelImporterService : No excel spread sheet uploaded");
	          }
	        }
	      }
	  } catch(IOException exception) {
		  this.log.error("doPost Method : IOException",exception);
	  } catch(Exception exception) {
		  this.log.error("doPost Method : Generic Exception",exception);
	  }
    
   
  }
  
  public int injectSpreadSheet(InputStream is)
  {
	  try
	    {
		    Map<String,Section> sections = null;
		    this.log.info("ExcelImporterService : Injecting Spread Sheet");
			XSSFWorkbook workbook = new XSSFWorkbook(is);

			/*
			 * Get first sheet from the workbook
			 */
			XSSFSheet sheet = workbook.getSheetAt(0);
			//Get iterator to all the rows in current sheet
			Iterator<Row> rowIterator = sheet.rowIterator();

			this.skipUnwantedRows(rowIterator,4);
			
			if(rowIterator.hasNext()) {
				sections = new HashMap<String,Section>();
			}
			while(rowIterator.hasNext()) {
				//Get iterator to all cells of current row
				injectProjectData(sections,rowIterator.next());
				creatEtcNodes(sections);
				addContentNodesForProducts(sections);
				
			}
	      return 0;
	    }
	    catch (Exception exception)
	    {
	      exception.printStackTrace();
	      this.log.error("Generic Exception: "+exception);
	    }
	    return -1;
	  }
  
  public void injectProjectData(Map<String,Section> sections,Row row) {
	
	  /*
	   * Parsing Section data
	   */
	  Section section=null;
	  String sectionValue = null;
	  Cell cell = row.getCell(ExcelImporterConstants.SECTION);
	  if(isValueAvailable(cell)) {
		  sectionValue = cell.getStringCellValue().trim();
	  } else {
		  return;
	  }
	 
	  if(sections.containsKey(sectionValue)) {
		  section = sections.get(sectionValue);
	  } else {
		  section = new Section();
		  section.setName(sectionValue);
		  sections.put(sectionValue, section);
	  }
	  
	  /*
	   * Parsing Range data
	   */
	  Range range = null;
	  String rangeValue = null;
	  cell = row.getCell(ExcelImporterConstants.RANGE);
	  if(isValueAvailable(cell)) {
		  rangeValue = cell.getStringCellValue().trim();
	  } else {
		  return;
	  }
	 
	  if(section.getRanges() == null ) {
		Map<String,Range> ranges =new HashMap<String,Range>();
		range = new Range();
		range.setName(rangeValue);
		ranges.put(rangeValue, range);
		section.setRanges(ranges);
	  } else if(section.getRanges().containsKey(rangeValue)) {
		  range = section.getRanges().get(rangeValue);
	  } else {
		  range = new Range();
		  range.setName(rangeValue);
		  section.getRanges().put(rangeValue, range);
	  }
	  
	  /*
	   * Parsing Category data
	   */
	  Category category = null;
	  String categoryValue=null;
	  
	  cell = row.getCell(ExcelImporterConstants.CATEGORY);
	  if(isValueAvailable(cell)) {
		   categoryValue = cell.getStringCellValue().trim(); 
	  } else {
		  return;
	  }
	   	
	  if(range.getCategories() == null ) {
			Map<String,Category> categories =new HashMap<String,Category>();
			category = new Category();
			category.setName(categoryValue);
			categories.put(categoryValue, category);
			range.setCategories(categories);
	  } else if(range.getCategories().containsKey(categoryValue)) {
		    category = range.getCategories().get(categoryValue);
	  } else {
		  category = new Category();
		  category.setName(categoryValue);
		   range.getCategories().put(categoryValue, category);
	  }
	  
	  /*
	   * Parsing Sub Category data
	   */
	  SubCategory subCategory = null;
	  String subCategoryValue = null;
	  
	  cell = row.getCell(ExcelImporterConstants.SUB_CATEGORY);
	  if(isValueAvailable(cell)) {
		  subCategoryValue = cell.getStringCellValue().trim();  
	  } else {
		  return;
	  }
	  	
	  if(category.getSubCategories() == null ) {
			Map<String,SubCategory> subCategories =new HashMap<String,SubCategory>();
			
			subCategory = new SubCategory();
			subCategory.setName(subCategoryValue);
			subCategories.put(subCategoryValue, subCategory);
			category.setSubCategories(subCategories);
	  } else if(category.getSubCategories().containsKey(subCategoryValue)) {
		    subCategory = category.getSubCategories().get(subCategoryValue);
	  } else {
		    subCategory = new SubCategory();
		    subCategory.setName(subCategoryValue);
		    category.getSubCategories().put(subCategoryValue, subCategory); 
	  }
	  
	  if(subCategory.getProducts() == null) {
		  Map<String,Product> products =new HashMap<String,Product>();
		  subCategory.setProducts(products);
	  }
	 
	  /*
	   * Parsing product data
	   */
	  Product product = new Product();
	  
	  cell = row.getCell(ExcelImporterConstants.SKU_PROPERTY_COLOR);
	  product.setColor(getCellValue(cell));
	  cell = row.getCell(ExcelImporterConstants.SKU_PROPERTY_COLOR_IMG);
	  product.setColorImage(getCellValue(cell));
	  cell = row.getCell(ExcelImporterConstants.SKU_PROPERTY_GIFT_WRAP);
	  product.setGiftWrap(getCellValue(cell));
	  cell = row.getCell(ExcelImporterConstants.SKU_PROPERTY_ENABLE_ECOMM);
	  product.setEnableEcomm(getCellValue(cell));
	  cell = row.getCell(ExcelImporterConstants.SKU_PRODUCT_NAME_VARIANT);
	  product.setIdentifier(getCellValue(cell));
	  cell = row.getCell(ExcelImporterConstants.SKU_PROPERTY_FAQ);
	  product.setFaq(getCellValue(cell));
	 
	  cell = row.getCell(ExcelImporterConstants.SKU_PROPERTY_PRODUCT_IMAGES);
	  String productImages = getCellValue(cell);
	  
	  if(productImages != null) {
		  product.setProductImages(productImages.split("\\s*,\\s*"));
	  }
	  
	  cell = row.getCell(ExcelImporterConstants.SKU_PROPERTY_PRODUCT_BROCHURE);
	  product.setProductBrochure(getCellValue(cell));
	  
	  cell = row.getCell(ExcelImporterConstants.SKU_PROPERTY_PRODUCT_MANUAL);
	  product.setProductManual(getCellValue(cell));
	  
	  cell =  row.getCell(ExcelImporterConstants.SKU_PROPERTY_PRODUCT_RECOMMENDATIONS);
	  String productRecommendations = getCellValue(cell);
	  
	  if(productRecommendations != null) {
		  product.setProductRecommendations(productRecommendations.split("\\s*,\\s*"));
	  }
	  
	  cell = row.getCell(ExcelImporterConstants.SKU_IMAGE_SUB_TITLE);
	  String subTitles = getCellValue(cell);
	  
	  if(subTitles != null) {
		  product.setSubTitles(subTitles.split("\\s*,\\s*"));
	  }
	  
	  cell = row.getCell(ExcelImporterConstants.SKU_PROPERTY_CQ_TAGS);
	  String cqTags = getCellValue(cell);
	  
	  if(cqTags != null) {
		  product.setCqTags(cqTags.split("\\s*,\\s*"));
	  }
	  
	  cell = row.getCell(ExcelImporterConstants.SUB_CATEGORY);
	  Cell cell2 = row.getCell(ExcelImporterConstants.SKU_PRODUCT_NAME_VARIANT);
	  product.setJcrTitle(getCellValue(cell)+"-"+getCellValue(cell2));
	  product.setTitle(getCellValue(cell)+"-"+getCellValue(cell2));

	  cell = row.getCell(ExcelImporterConstants.SKU_IMAGE_PATH);
	  product.setImageNodeURL(getCellValue(cell));
	  
	  String[] quickFeatureHeaders = new String[4];
	  String[] quickFeatureDescription = new String[4];
	  int j=0;
	  for(int i=ExcelImporterConstants.SKU_OTHER_INFO_QUICK_FEATURES_STARTING_INDEX; i <= ExcelImporterConstants.SKU_OTHER_INFO_QUICK_FEATURES_ENDING_INDEX; i=i+2 ) {
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_QUICK_FEATURES_HEADING);
		  quickFeatureHeaders[j]=getCellValue(cell);

		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_QUICK_FEATURES_DESCTIPTION);
		  quickFeatureDescription[j]=getCellValue(cell);
		  
		  j++;
	  }
	  product.setQuickFeaturesHeaders(quickFeatureHeaders);
	  product.setQuickFeaturesDescriptions(quickFeatureDescription);
	  
	  String[] detailFeatureHeaders = new String[25];
	  String[] detailFeatureDescription = new String[25];
	  String[] detailFeatureIages = new String[25];
	  
	  j=0;
	  for(int i=ExcelImporterConstants.SKU_OTHER_INFO_DETAIL_FEATURES_STARTING_INDEX; i <= ExcelImporterConstants.SKU_OTHER_INFO_DETAIL_FEATURES_ENDING_INDEX; i=i+3 ) {
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_DETAIL_FEATURES_IMAGE);
		  detailFeatureHeaders[j]=getCellValue(cell);

		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_DETAIL_FEATURES_HEADING);
		  detailFeatureDescription[j]=getCellValue(cell);
		  
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_DETAIL_FEATURES_DESCRIPTION);
		  detailFeatureIages[j]=getCellValue(cell);
		  
		  j++;
	  }
	  product.setDetailFeaturesHeaders(detailFeatureHeaders);
	  product.setDetailFeaturesDesciptions(detailFeatureDescription);
	  product.setDetailFeaturesImages(detailFeatureIages);
	  
	  String[] optionalFeatureHeaders = new String[25];
	  String[] optionalFeatureDescription = new String[25];
	  String[] optionalFeatureIages = new String[25];
	  
	  j=0;
	  for(int i=ExcelImporterConstants.SKU_OTHER_INFO_OPTIONAL_FEATURES_STARTING_INDEX; i <= ExcelImporterConstants.SKU_OTHER_INFO_OPTIONAL_FEATURES_ENDING_INDEX; i=i+3 ) {
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_OPTIONAL_FEATURES_HEADING);
		  optionalFeatureHeaders[j]=getCellValue(cell);

		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_OPTIONAL_FEATURES_DESCRIPTION);
		  optionalFeatureDescription[j]=getCellValue(cell);
		  
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_OPTIONAL_FEATURES_IMAGE);
		  optionalFeatureIages[j]=getCellValue(cell);
		  
		  j++;
	  }
	  product.setOptionalFeaturesHeaders(optionalFeatureHeaders);
	  product.setOptionalFeaturesDesciptions(optionalFeatureDescription);
	  product.setOptionalFeaturesImages(optionalFeatureIages);
	  
	  List<Headers> technicalSpecheaders=new ArrayList<Headers>();
	  Headers header = null;
	  j=0;
	  for(int i=ExcelImporterConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_STARTING_INDEX; i <= ExcelImporterConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_ENDING_INDEX; i=i+3 ) {
		  header=new Headers();
		  
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_KEY);
		  header.setKey(getCellValue(cell));
		  
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_VALUE);
		  
		   String values = getCellValue(cell);
		  
		  
		   header.setValue(values);
		 
		  
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_CQ_TAGS);
		  String techSpecTags = getCellValue(cell);
		  
		  
		   header.setCqTag(techSpecTags.replaceAll(" / ", "/"));
		  
		  technicalSpecheaders.add(header);
		  j++;
	  }
	  product.setTechnicalSpecHeaders(technicalSpecheaders);
	  
	  cell = row.getCell(ExcelImporterConstants.SKU_OTHER_INFO_TECHNICAL_SPEC_IMAGE_PROPERTY);
	  String technicalSpecImages = getCellValue(cell);
	  
	  if(technicalSpecImages != null) {
		  product.setTechnicalSpecImages(technicalSpecImages.split("\\s*,\\s*"));
	  }
	  
	  String[] accessoryHeaders = new String[20];
	  String[] accessoryDescriptions = new String[20];
	  String[] accessoryImages = new String[20];
	  j=0;
	  for(int i=ExcelImporterConstants.SKU_OTHER_INFO_ACCESSORY_STARTING_INDEX; i <= ExcelImporterConstants.SKU_OTHER_INFO_ACCESSORY_ENDING_INDEX; i=i+3 ) {
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_ACCESSORY_HEADING);
		  accessoryHeaders[j]=getCellValue(cell);
		  
		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_ACCESSORY_DESCRIPTION);
		  accessoryDescriptions[j]=getCellValue(cell);

		  cell = row.getCell(i + ExcelImporterConstants.SKU_OTHER_INFO_ACCESSORY_IMAGE);
		  accessoryImages[j]=getCellValue(cell);
		  j++;
	  }
	  product.setAccessoryHeaders(accessoryHeaders);
	  product.setAccessoryDesciptions(accessoryDescriptions);
	  product.setAccessoryImages(accessoryImages);
	  
	  cell = row.getCell(ExcelImporterConstants.SKU_OTHER_INFO_TECHNICAL_DRAWING_IMAGES);
	  String technicalDrawingImages = getCellValue(cell);
	  
	  if(technicalDrawingImages != null) {
		  product.setTechnicalDrawingImages(technicalDrawingImages.split("\\s*,\\s*"));
	  }
	  
	  cell = row.getCell(ExcelImporterConstants.SKU_OTHER_INFO_YOU_TUBE_URLS);
	  String youTubeURLS = getCellValue(cell);
	  
	  if(youTubeURLS != null) {
		  product.setYouTubeURLS(youTubeURLS.split("\\s*,\\s*"));
	  }
	  
	  subCategory.getProducts().put(product.getIdentifier(), product);
  }
  
  public void skipUnwantedRows(Iterator<Row> rowIterator,int rowsToSkip) {
	  if(rowIterator != null) {
		  int i=0;
		  while(i < rowsToSkip && rowIterator.hasNext()) {
			  rowIterator.next();
			  i++;
		  }
	  }
  }
  
  public boolean isValueAvailable(Cell cell) {
	  if(cell != null) {
		  cell.setCellType(Cell.CELL_TYPE_STRING);
		  if(!"".equals(cell.getStringCellValue().trim())) {
			  return true;
		  }
	  }
	  return false;
  }
  
  public String getCellValue(Cell cell) {
	  if(isValueAvailable(cell)) {
		  return cell.getStringCellValue().trim();
	  }
	  return "";
  }
  
  public void creatEtcNodes(Map<String,Section> sections) {
	  
	  try {
		  ResourceResolver resourceResolver = this.resolverFactory.getAdministrativeResourceResolver(null);
		  this.session = ((Session)resourceResolver.adaptTo(Session.class));
		  
		  Resource resource = resourceResolver.getResource(excelImporterService.getEtcPathToCreateProductsNode());
		  
		  if(resource == null) {
			  Node rootNode = this.session.getRootNode();
			  Node node = rootNode.addNode(excelImporterService.getEtcPathToCreateProductsNode().substring(1));
			  node.setProperty(ExcelImporterConstants.CQ_COMMERECE_PROVIDER_PROPERTY, "havells");
			  this.session.save();
		  } 
		  
		  Iterator<Entry<String, Section>> sectionsInterator = sections.entrySet().iterator();
		  
		  while(sectionsInterator.hasNext()) {
			  @SuppressWarnings("rawtypes")
			  Map.Entry sectionEntry = (Map.Entry) sectionsInterator.next();
			  Section section = (Section) sectionEntry.getValue();
			  Resource sectionResource = resource.getChild(section.getName());
			  Node sectionNode = null;
			  
			  if(sectionResource == null) {
				  sectionNode = resource.adaptTo(Node.class).addNode(section.getName());
				  sectionNode.setProperty("sling:resourceType", "");
				  
			  } else {
				  sectionNode = sectionResource.adaptTo(Node.class);
			  }
			  
			  if(!sectionNode.hasNode("jcr:content")) {
				  createThumbailFolder(sectionNode);
			  }
			  
			  addRanges(section.getRanges(),sectionResource);
			  this.session.save();
			  this.session.refresh(true);
		  }
		  
	  } catch(Exception exception) {
		 exception.printStackTrace();
	  }
  }
  
  @SuppressWarnings("rawtypes")
  public void addRanges(Map<String,Range> ranges, Resource sectionResource) throws ItemExistsException, PathNotFoundException, VersionException, ConstraintViolationException, LockException, RepositoryException {
	  
	  if(sectionResource != null) {
		  Iterator<Entry<String, Range>> rangesInterator = ranges.entrySet().iterator();
		  
		  while(rangesInterator.hasNext()) {
			 
			  Map.Entry rangeEntry = (Map.Entry) rangesInterator.next();
			  Range range = (Range) rangeEntry.getValue();
			  Resource rangeResource = sectionResource.getChild(range.getName());
			  Node rangeNode=null;

			  if(rangeResource == null) {
				  rangeNode = sectionResource.adaptTo(Node.class).addNode(range.getName());
				  rangeNode.setProperty("sling:resourceType", "");
			  }  else {
				  rangeNode = rangeResource.adaptTo(Node.class);
			  }
			  
			  if(!rangeNode.hasNode("jcr:content")) {
				  createThumbailFolder(rangeNode);
			  }
			  
			  addCategories(range.getCategories(),rangeResource);
			  this.session.save();
			  this.session.refresh(true);
		  }
	  }
	 
	  
  }
  
  @SuppressWarnings("rawtypes")
  public void addCategories(Map<String,Category> categories, Resource rangeResource) throws ItemExistsException, PathNotFoundException, VersionException, ConstraintViolationException, LockException, RepositoryException {
	  
	  if(rangeResource != null) {
		  Iterator<Entry<String, Category>> categoriesInterator = categories.entrySet().iterator();
		  
		  while(categoriesInterator.hasNext()) {
			  Map.Entry categoryEntry = (Map.Entry) categoriesInterator.next();
			  Category category = (Category) categoryEntry.getValue();
			  
			  Resource categoryResource = rangeResource.getChild(category.getName());
			  
			  Node categoryNode = null;
			  if(categoryResource == null) {
				  categoryNode = rangeResource.adaptTo(Node.class).addNode(category.getName());
				  categoryNode.setProperty("sling:resourceType", "");
				 
			  }   else {
				  categoryNode = categoryResource.adaptTo(Node.class);
			  }
			  
			  if(!categoryNode.hasNode("jcr:content")) {
				  createThumbailFolder(categoryNode);
			  }
			  
			  addSubCategories(category.getSubCategories(),categoryResource);
			  this.session.save();
			  this.session.refresh(true);
		  }
	  }
	 
	  
  }
 
  @SuppressWarnings("rawtypes")
  public void addSubCategories(Map<String,SubCategory> subCategories, Resource categoryResource) throws ItemExistsException, PathNotFoundException, VersionException, ConstraintViolationException, LockException, RepositoryException {
	  
	  if(categoryResource != null) {
		  Iterator<Entry<String, SubCategory>> subCategoriesInterator = subCategories.entrySet().iterator();
		  
		  while(subCategoriesInterator.hasNext()) {
			  Map.Entry subCategoryEntry = (Map.Entry) subCategoriesInterator.next();
			  SubCategory subCategory = (SubCategory) subCategoryEntry.getValue();
			  Resource subCategoryResource = categoryResource.getChild(subCategory.getName().toLowerCase().replace(' ','-'));
			  Node subCategoryNode = null;

			  if(subCategoryResource == null) {
				  subCategoryNode = categoryResource.adaptTo(Node.class).addNode(subCategory.getName().toLowerCase().replace(' ','-'));
				  subCategoryNode.setProperty("sling:resourceType", "");
			  }  else {
				  subCategoryNode = subCategoryResource.adaptTo(Node.class);
			  }
			  
			  if(!subCategoryNode.hasNode("jcr:content")) {
				  createThumbailFolder(subCategoryNode);
			  }
			  
			  addProducts(subCategory.getProducts(),subCategoryResource);
			  this.session.save();
			  this.session.refresh(true);
		  }
	  }
	 
	  
  }
 
  @SuppressWarnings("rawtypes")
  public void addProducts(Map<String,Product> products, Resource subCategoryResource) throws ItemExistsException, PathNotFoundException, VersionException, ConstraintViolationException, LockException, RepositoryException {
	  
	  if(subCategoryResource != null) {
		  Iterator<Entry<String, Product>> subCategoriesInterator = products.entrySet().iterator();
		  
		  while(subCategoriesInterator.hasNext()) {
			  Map.Entry productEntry = (Map.Entry) subCategoriesInterator.next();
			  Product product = (Product) productEntry.getValue();
			  
			  Resource productResource = subCategoryResource.getChild(product.getIdentifier().toLowerCase());
			  Node productNode = null;
			  if(productResource == null) {
				  productNode = subCategoryResource.adaptTo(Node.class).addNode(product.getIdentifier().toLowerCase());
				  productNode.setProperty("sling:resourceType", "commerce/components/product");
				  productNode.setPrimaryType("nt:unstructured");
			  } else {
				  productNode = productResource.adaptTo(Node.class);
			  }
			  
			 addSKUNodeProperties(productNode, product);
			 
			 Node imageNode = null;
			 if(!productNode.hasNode("image")) {
				 imageNode = productNode.addNode("image");
				 imageNode.setPrimaryType("nt:unstructured");
			 } else {
				 imageNode = productNode.getNode("image");
			 }
			 
			 imageNode.setProperty("sling:resourceType", "commerce/components/product/image");
			 imageNode.setProperty(ExcelImporterConstants.IMAGE_FILE_REFERENCE_PROPERTY, product.getImageNodeURL());
			 
			
			 Node otherIndoNode = null;
			 if(!productNode.hasNode("otherInfo")) {
				 otherIndoNode = productNode.addNode("otherInfo");
				 otherIndoNode.setPrimaryType("nt:unstructured");
			 } else {
				 otherIndoNode = productNode.getNode("otherInfo");
			 }
				 
			 Node quickFeaturesNode = null;
			 if(!otherIndoNode.hasNode(ExcelImporterConstants.QUICK_FEATURES_NODE)) {
				 quickFeaturesNode = otherIndoNode.addNode(ExcelImporterConstants.QUICK_FEATURES_NODE);
				 quickFeaturesNode.setPrimaryType("nt:unstructured");
			 } else {
				 quickFeaturesNode = otherIndoNode.getNode(ExcelImporterConstants.QUICK_FEATURES_NODE);
			 }
			 
			 addArrayProperties(quickFeaturesNode,product.getQuickFeaturesHeaders(),ExcelImporterConstants.HEADER_PROPERTY_PREFIX);
			 addArrayProperties(quickFeaturesNode,product.getQuickFeaturesDescriptions(),ExcelImporterConstants.DESCRIPTION_PROPERTY_PREFIX);
			
			 Node detailFeaturesNode = null;
			 if(!otherIndoNode.hasNode(ExcelImporterConstants.DETAIL_FEATURES_NODE)) {
				 detailFeaturesNode = otherIndoNode.addNode(ExcelImporterConstants.DETAIL_FEATURES_NODE);
				 detailFeaturesNode.setPrimaryType("nt:unstructured");
			 } else {
				 detailFeaturesNode = otherIndoNode.getNode(ExcelImporterConstants.DETAIL_FEATURES_NODE);
			 }
			 
			 addArrayProperties(detailFeaturesNode,product.getDetailFeaturesHeaders(),ExcelImporterConstants.HEADER_PROPERTY_PREFIX);
			 addArrayProperties(detailFeaturesNode,product.getDetailFeaturesDesciptions(),ExcelImporterConstants.DESCRIPTION_PROPERTY_PREFIX);
			 addArrayProperties(detailFeaturesNode,product.getDetailFeaturesImages(),ExcelImporterConstants.IMAGE_PROPERTY_PREFIX);
			 
			 
			 Node optionalFeaturesNode = null;
			 if(!otherIndoNode.hasNode(ExcelImporterConstants.OPTIONAL_FEATURES_NODE)) {
				 optionalFeaturesNode = otherIndoNode.addNode(ExcelImporterConstants.OPTIONAL_FEATURES_NODE);
				 optionalFeaturesNode.setPrimaryType("nt:unstructured");
			 } else {
				 optionalFeaturesNode = otherIndoNode.getNode(ExcelImporterConstants.OPTIONAL_FEATURES_NODE);
			 }
			 
			 addArrayProperties(optionalFeaturesNode,product.getOptionalFeaturesHeaders(),ExcelImporterConstants.HEADER_PROPERTY_PREFIX);
			 addArrayProperties(optionalFeaturesNode,product.getOptionalFeaturesDesciptions(),ExcelImporterConstants.DESCRIPTION_PROPERTY_PREFIX);
			 addArrayProperties(optionalFeaturesNode,product.getOptionalFeaturesImages(),ExcelImporterConstants.IMAGE_PROPERTY_PREFIX);
			 
			 Node technicalSpecNode= null;
			 if(!otherIndoNode.hasNode(ExcelImporterConstants.TECHNICAL_SPEC_NODE)) {
				 technicalSpecNode = otherIndoNode.addNode(ExcelImporterConstants.TECHNICAL_SPEC_NODE);
				 technicalSpecNode.setPrimaryType("nt:unstructured");
			 } else {
				 technicalSpecNode= otherIndoNode.getNode(ExcelImporterConstants.TECHNICAL_SPEC_NODE);
			 }
			 technicalSpecNode.setProperty("images", product.getTechnicalSpecImages());
			 
			 
			 List<Headers> technicalSpecHeaders = product.getTechnicalSpecHeaders();
			 
			 Iterator<Headers> headersIterator = technicalSpecHeaders.iterator();
			 
			 int k=1;
			 while(headersIterator.hasNext()) {
				 Headers headers = headersIterator.next();
				 Node headerNode= null;
				 if(!technicalSpecNode.hasNode(ExcelImporterConstants.HEADER_PROPERTY_PREFIX+k)) {
					 headerNode = technicalSpecNode.addNode(ExcelImporterConstants.HEADER_PROPERTY_PREFIX+k);
					 headerNode.setPrimaryType("nt:unstructured");
				 } else {
					 headerNode = technicalSpecNode.getNode(ExcelImporterConstants.HEADER_PROPERTY_PREFIX+k);
				 }
				 String tag = "";
				 if(!headers.getValue().equals("") || !headers.getCqTag().equals("")) {
					 tag=ExcelImporterConstants.TAG_PREFIX;
				 }
				 if(!headers.getValue().equals("")) {
					 tag+="/"+headers.getValue().toLowerCase().replaceAll(" ", "-");
				 }
				 if(!headers.getCqTag().equals("")) {
					 tag+="/"+headers.getCqTag().toLowerCase().replaceAll(" ", "-");
				 }
				 String[] tags = {tag};
				 headerNode.setProperty(ExcelImporterConstants.CQ_TAGS_PROPERTY, tags);
				 headerNode.setProperty(ExcelImporterConstants.KEY_PROPERTY,tag);
				 headerNode.setProperty(ExcelImporterConstants.VALUE_PROPERTY, headers.getKey());
				 k++;
				
			 }
			 
			 Node accessoryNode = null;
			 if(!otherIndoNode.hasNode(ExcelImporterConstants.ACCESSORY_NODE)) {
				 accessoryNode = otherIndoNode.addNode(ExcelImporterConstants.ACCESSORY_NODE);
				 accessoryNode.setPrimaryType("nt:unstructured");
			 } else {
				 accessoryNode = otherIndoNode.getNode(ExcelImporterConstants.ACCESSORY_NODE);
			 }
			 
			 addArrayProperties(accessoryNode,product.getAccessoryHeaders(),ExcelImporterConstants.HEADER_PROPERTY_PREFIX);
			 addArrayProperties(accessoryNode,product.getAccessoryDesciptions(),ExcelImporterConstants.DESCRIPTION_PROPERTY_PREFIX);
			 addArrayProperties(accessoryNode,product.getAccessoryImages(),ExcelImporterConstants.IMAGE_PROPERTY_PREFIX);

			
			 Node technicalDrawingNode = null;
			 if(!otherIndoNode.hasNode(ExcelImporterConstants.TECHNICAL_DRAWING_IMAGES)) {
				 technicalDrawingNode = otherIndoNode.addNode(ExcelImporterConstants.TECHNICAL_DRAWING_IMAGES);
				 technicalDrawingNode.setPrimaryType("nt:unstructured");
			 } else {
				 technicalDrawingNode = otherIndoNode.getNode(ExcelImporterConstants.TECHNICAL_DRAWING_IMAGES);
			 }
			 
			 technicalDrawingNode.setProperty("drawingImages", product.getTechnicalDrawingImages());
			 
			
		  }
	  }
	 
	  
 }
  
  public void addSKUNodeProperties(Node productNode, Product product) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException {
    	 productNode.setProperty("backgroundImg", product.getBackgroungImage());
		 productNode.setProperty("color", product.getColor());
		 productNode.setProperty("img", product.getImageNodeURL());
		 productNode.setProperty("cq:commerceType", "product");
		 productNode.setProperty("cqTags", product.getCqTags());
		 productNode.setProperty("damVideo", "");
		 productNode.setProperty("enableEcomm", product.getEnableEcomm());
		 productNode.setProperty("faq", product.getFaq());
		 productNode.setProperty("giftWrap", product.getGiftWrap());
		 productNode.setProperty("identifier", product.getIdentifier());
		 productNode.setProperty("jcr:title", product.getJcrTitle());
		 productNode.setProperty("pagePath", product.getPagePath());
		 productNode.setProperty("productBrochure", product.getProductBrochure());
		 productNode.setProperty("productManual", product.getProductManual());
		 productNode.setProperty("productRecommendation", product.getProductRecommendations());
		 productNode.setProperty("subTitle", product.getSubTitles());
		 productNode.setProperty("title", product.getTitle());
		 productNode.setProperty("youtube", product.getYouTubeURLS()); 

		 this.session.save();
		 
  }
  
  public void addArrayProperties(Node node, String[] properties, String property_prefix) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException {
	  
	  if(properties.length > 0) {
			 for(int i=0; i< properties.length; i++) {
				 node.setProperty(property_prefix+(i+1), properties[i]);
			 }
		 }
  }
 
  public void createThumbailFolder(Node node) throws ItemExistsException, PathNotFoundException, VersionException, ConstraintViolationException, LockException, RepositoryException {
	  
	  Node parentJcrNode = node.addNode("jcr:content","nt:unstructured");
	  parentJcrNode.setProperty("dam:descriptions","");	  
	  
	  
	  Node fileNode = parentJcrNode.addNode("folderThumbnail","nt:file");
	 
	  if(fileNode != null) {
		  Node jcrNode = fileNode.addNode("jcr:content","nt:unstructured");
		 
		  jcrNode.setProperty("bgcolor", -1);
		  jcrNode.setProperty("dam:descriptions","");	  
		  jcrNode.setProperty("dam:folderThumbnailPaths","");	  
		  jcrNode.setProperty("height",140);
		  jcrNode.setProperty("jcr:mimeType", "application/octet-stream");	  
		  jcrNode.setProperty("width",240);

	  }
	  
	  this.session.save();
  }
  
  @SuppressWarnings("rawtypes")  
  public void addContentNodesForProducts(Map<String,Section> sections) {
	  
	  try {
		  if(sections != null) {
			  Iterator<Entry<String, Section>> sectionsInterator = sections.entrySet().iterator();
			  final String parentPath = excelImporterService.getContentPathToCreatePages();
			  while(sectionsInterator.hasNext()) {
				  Map.Entry sectionEntry = (Map.Entry) sectionsInterator.next();
				  Section section = (Section) sectionEntry.getValue();
				  addContentPage(parentPath,section);
				  
				  Iterator<Entry<String,Range>> rangesIterator = section.getRanges().entrySet().iterator();
				  
				  while(rangesIterator.hasNext()) {
					  Map.Entry rangeEntry = (Map.Entry) rangesIterator.next();
					  Range range = (Range) rangeEntry.getValue();
					  final String rangeParentPath = parentPath+"/"+section.getName().replace(' ','-');
					  addContentPage(rangeParentPath,range);
					  
					  Iterator<Entry<String,Category>> categoriesIterator = range.getCategories().entrySet().iterator();
					  
					  while(categoriesIterator.hasNext()) {
						  Map.Entry categoryEntry = (Map.Entry) categoriesIterator.next();
						  Category category = (Category) categoryEntry.getValue();
						  final String categoryParentPath = rangeParentPath+"/"+range.getName().replace(' ','-');
						  addContentPage(categoryParentPath,category);
						  
						  Iterator<Entry<String,SubCategory>> subCategoriesIterator = category.getSubCategories().entrySet().iterator();
						  
						  while(subCategoriesIterator.hasNext()) {
							  Map.Entry subCateogryEntry = (Map.Entry) subCategoriesIterator.next();
							  SubCategory subCategory = (SubCategory) subCateogryEntry.getValue();
							  final String subcategoryParentPath = categoryParentPath+"/"+category.getName().replace(' ','-');
							  addContentPage(subcategoryParentPath,subCategory);
							  
							  Iterator<Entry<String,Product>> productsIterator = subCategory.getProducts().entrySet().iterator();
						
							  while(productsIterator.hasNext()) {
								  Map.Entry productEntry = (Map.Entry) productsIterator.next();
								  Product product = (Product) productEntry.getValue();
								  final String productParentPath = subcategoryParentPath+"/"+subCategory.getName().toLowerCase().replace(' ','-');
								  addContentPage(productParentPath,product);
							  }
						  }
					  }
				  }
						
			  }
		  }  
	  } catch(Exception exception) {
		  this.log.error("addContentNodesForProducts(): Generic Exception:",exception);
	  }
	  
	  
  }
  
  public void addContentPage(final String parentPath,Object object) {
	  
	  String pageName = null;
	  String pageTitle = null;
	  boolean isProductPage= false;
	  if(object instanceof Section ) {
		  Section section = (Section) object;
		  pageName = section.getName();
		  pageTitle = pageName.substring(0,1).toUpperCase()+pageName.substring(1);
	  } else if(object instanceof Range) {
		  Range range = (Range) object;
		  pageName = range.getName();
		  pageTitle = pageName.substring(0,1).toUpperCase()+pageName.substring(1);
	  } else if(object instanceof Category) {
		  Category category = (Category) object;
		  pageName = category.getName();
		  pageTitle = pageName.substring(0,1).toUpperCase()+pageName.substring(1);
	  } else if(object instanceof SubCategory) {
		  SubCategory subCategory = (SubCategory) object;
		  pageName = subCategory.getName().toLowerCase();
		  pageTitle = pageName.substring(0,1).toUpperCase()+pageName.substring(1);
	  } else if(object instanceof Product) {
		  Product product = (Product) object;
		  pageName = product.getJcrTitle().toLowerCase();
		  pageTitle = product.getJcrTitle().toLowerCase();
		  isProductPage = true;
	  }
	  
	  try {  
		  ResourceResolver resourceResolver = this.resolverFactory.getAdministrativeResourceResolver(null);
		  this.session = ((Session)resourceResolver.adaptTo(Session.class));
		  Page prodPage = null;
		  if (this.session != null) {
		    	 
		     /* 
		      * Create Page        
		      */
		      PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
		      if(pageManager.getPage(parentPath+"/"+pageName.replace(' ', '-')) == null) {
		    	  prodPage = pageManager.create(parentPath, pageName.replace(' ', '-'), ExcelImporterConstants.CONTENT_TEMPLATE, pageTitle);
			      Node pageNode = prodPage.adaptTo(Node.class);
				  
			      Node jcrNode = null;
			      if (prodPage.hasContent()) {
			        jcrNode = prodPage.getContentResource().adaptTo(Node.class);
			      } else {                   
			        jcrNode = pageNode.addNode("jcr:content", "cq:PageContent");
			      } 
			      jcrNode.setProperty("sling:resourceType", ExcelImporterConstants.CONTENT_COMPONENT);
			      Node parNode = jcrNode.addNode("par");
			      parNode.setProperty("sling:resourceType", "foundation/components/parsys");
			      if(!(object instanceof Product)) {
			    	  Node imageNode = jcrNode.addNode("image");
				      imageNode.setProperty("imageRotate", "0");
			    	    
			      } 
			      
			      if(object instanceof Section) {
			    	  Node mainNav = parNode.addNode(ExcelImporterConstants.MAIN_NAV_NODE_NAME);
			    	  mainNav.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.MAIN_NAV_COMPONENT_NAME);
			    	  
			    	  Node productGrid = parNode.addNode(ExcelImporterConstants.PRODUCT_GRID_NODE_NAME);
			    	  productGrid.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.PRODUCT_GRID_COMPONENT);
			    	  
			    	  Node categoryColumnVideo = parNode.addNode(ExcelImporterConstants.CATEGORY_COLUMN_VIDEO_NODE_NAME);
			    	  categoryColumnVideo.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.CATEGORY_COLUMN_VIDEO_COMPONENT);
			    	  
			    	  Node news = parNode.addNode(ExcelImporterConstants.NEWS_NODE_NAME);
			    	  news.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.NEWS_COMPONENT);
			    	 
			    	  Node connect = parNode.addNode(ExcelImporterConstants.CONNECT_NODE_NAME);
			    	  connect.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.CONNECT_COMPONENT);
			      
			      }
			      
			      if(object instanceof Range) {
			    	  Node topNavigation = parNode.addNode(ExcelImporterConstants.TOP_NAVIGATION_NODE_NAME);
			    	  topNavigation.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.TOP_NAVIGATION_COMPONENT);
			    	  
			    	  Node productCategory = parNode.addNode(ExcelImporterConstants.PRODUCT_CATEGORY_NODE_NAME);
			    	  productCategory.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.PRODUCT_CATEGORY_COMPONENT);
			    	  
			    	  Node midbanner = parNode.addNode(ExcelImporterConstants.MID_BANNER_NODE_NAME);
			    	  midbanner.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.MID_BANNER_COMPONENT);
			    	  
			    	  Node news = parNode.addNode(ExcelImporterConstants.NEWS_NODE_NAME);
			    	  news.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.NEWS_COMPONENT);
			    	 
			    	  Node connect = parNode.addNode(ExcelImporterConstants.CONNECT_NODE_NAME);
			    	  connect.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.CONNECT_COMPONENT);
			      
			      }
			      if(object instanceof Category) {
			    	  Node topNavigation = parNode.addNode(ExcelImporterConstants.TOP_NAVIGATION_NODE_NAME);
			    	  topNavigation.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.TOP_NAVIGATION_COMPONENT);
			    	  
			    	  Node productSubCategory = parNode.addNode(ExcelImporterConstants.PRODUCT_SUB_CATEGORY_NODE_NAME);
			    	  productSubCategory.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.PRODUCT_SUB_CATEGORY_COMPONENT);
			    	  
			    	  Node midbanner = parNode.addNode(ExcelImporterConstants.MID_BANNER_NODE_NAME);
			    	  midbanner.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.MID_BANNER_COMPONENT);
			    	  
			    	  Node columnVideo = parNode.addNode(ExcelImporterConstants.COLUMN_VIDEO_NODE_NAME);
			    	  columnVideo.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.COLUMN_VIDEO_COMPONENT);

			    	  Node news = parNode.addNode(ExcelImporterConstants.NEWS_NODE_NAME);
			    	  news.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.NEWS_COMPONENT);
			    	 
			    	  Node connect = parNode.addNode(ExcelImporterConstants.CONNECT_NODE_NAME);
			    	  connect.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.CONNECT_COMPONENT);
			      
			      }
			      if(object instanceof SubCategory) {
			    	  Node topBanner = parNode.addNode(ExcelImporterConstants.TOP_BANNER_NODE_NAME);
			    	  topBanner.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.TOP_BANNER_COMPONENT);
			    	  
			    	  Node sortProducts = parNode.addNode(ExcelImporterConstants.SORT_PRODUCTS_NODE_NAME);
			    	  sortProducts.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.SORT_PRODUCTS_COMPONENT);
			    	  
			    	  Node searchContainer = parNode.addNode(ExcelImporterConstants.SEARCH_CONTAINER_NODE_NAME);
			    	  searchContainer.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.SEARCH_CONTAINER_COMPONENT);
			    	  
			    	  Node productDetailsGrid = parNode.addNode(ExcelImporterConstants.PRODUCT_DETAILS_GRID_NODE_NAME);
			    	  productDetailsGrid.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.PRODUCT_DETAILS_GRID_COMPONENT);
			    	  
			    	  Node connect = parNode.addNode(ExcelImporterConstants.CONNECT_NODE_NAME);
			    	  connect.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.CONNECT_COMPONENT);
			    	  
			    	  
			      }
			      if(object instanceof Product) {
			    	  Node headerIPar = jcrNode.addNode("aboutus-header-ipar");
			    	  headerIPar.setProperty("sling:resourceType", "foundation/components/iparsys");
			    	  
			    	  Node productDetailPage = headerIPar.addNode("productdetailpage");
			    	  productDetailPage.setProperty("sling:resourceType", "havells/components/content/productdetailpage");
			    	  productDetailPage.setProperty("jcr:Sku", ((Product) object).getIdentifier());
			    	  
			    	  Node relatedProducts = parNode.addNode(ExcelImporterConstants.RELATED_PRODUCTS_NAME);
			    	  relatedProducts.setProperty(ExcelImporterConstants.SLING_RESOURCE_TYPE_PROPERTY, ExcelImporterConstants.RELATED_PRODUCTS_COMPONENT);
			    	  
			      }
			      
			    
			       this.session.save();
			       this.session.refresh(true);
		      }
		     
		  }
		            
		 } catch (Exception e) {
		  this.log.error("addContentPage() : Generic Exception:"+e);
		 }   
  }
  protected void bindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
  {
    this.resolverFactory = paramResourceResolverFactory;
  }
  
  protected void unbindResolverFactory(ResourceResolverFactory paramResourceResolverFactory)
  {
    if (this.resolverFactory == paramResourceResolverFactory) {
      this.resolverFactory = null;
    }
  }
  
}
