package com.havells.excel.importer.DTO;

public class Headers {

	private String cqTag;

	private String key;
	
	private String value;
	
	

	public String getCqTag() {
		return cqTag;
	}

	public void setCqTag(String cqTag) {
		this.cqTag = cqTag;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	
}
