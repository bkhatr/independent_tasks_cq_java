package com.havells.excel.importer.DTO;

import java.util.List;
import java.util.Map;

public class SubCategory {

	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, Product> getProducts() {
		return products;
	}

	public void setProducts(Map<String, Product> products) {
		this.products = products;
	}

	private Map<String, Product> products;
}
