package com.havells.excel.importer.servlet;

import java.io.IOException;

import java.rmi.ServerException;
import java.util.List;

import com.google.gson.Gson;

import org.apache.felix.scr.annotations.sling.SlingServlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;


import com.havells.excel.importer.utils.ProductsDataUtil;

@SlingServlet(
        label = "Product data list - Sling All Methods Servlet",
        description = "Product data listing.",
        paths = { "/bin/productdata" },
        methods = { "GET", "POST" } // Ignored if paths is set - Defaults to GET if not specified
)
public class ProductDataServlet  extends SlingAllMethodsServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
		    throws ServerException, IOException {
		
		boolean isRange = request.getParameter("isRange") != null ? true : false;
		String range = null;
		if(isRange) {
			range = request.getParameter("range");
		}
		boolean isSection = request.getParameter("isSection") != null ? true : false;
		if(isSection) {
			range = request.getParameter("range");
		}
		if(!isRange && !isSection) {
			return;
		}
		List<String> list = null;
		if(isRange) {
			list = ProductsDataUtil.getRangeList();
			
		}
		if(isSection) {
			list = ProductsDataUtil.getSectionList(range);
		}
		String jsonString = new Gson().toJson(list);
		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(jsonString);
	}
}
