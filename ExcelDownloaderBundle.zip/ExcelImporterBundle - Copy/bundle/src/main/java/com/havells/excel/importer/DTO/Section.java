package com.havells.excel.importer.DTO;

import java.util.List;
import java.util.Map;


public class Section implements Comparable<Section> {

	private String name;
	
	private  Map<String,Range> ranges;

	public int compareTo(Section object) {
		return this.name.compareTo(object.name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String,Range> getRanges() {
		return ranges;
	}

	public void setRanges( Map<String,Range> ranges) {
		this.ranges = ranges;
	}
	
}
