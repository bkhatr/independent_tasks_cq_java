package com.havells.excel.importer.utils;

import java.util.ArrayList;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryResult;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ProductsDataUtil {
	protected static final Logger log = LoggerFactory.getLogger(ProductsDataUtil.class);
	
	public static <T> T getServiceReference(final Class<T> serviceClass) {
		T serviceRef;
		/**
		* Get the BundleContext associated with the passed class reference.
		*/
		BundleContext bundleContext = FrameworkUtil.getBundle(serviceClass).getBundleContext();
		ServiceReference osgiRef = bundleContext
		.getServiceReference(serviceClass.getName());
		serviceRef = (T) bundleContext.getService(osgiRef);
		return serviceRef;
	}
	
	public static List<String> getRangeList() {
		
		ResourceResolverFactory resolverFactory = getServiceReference(ResourceResolverFactory.class);
		ResourceResolver resourceResolver;
		List<String> rangeList = new ArrayList<String>();
		try {
			resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			Resource resource = resourceResolver.getResource("/etc/commerce/products/havells");
			Node node = resource.adaptTo(Node.class);
			
				NodeIterator nodeIterator = node.getNodes();
				while(nodeIterator.hasNext()) {
					Node nextNode = nodeIterator.nextNode();
					if(!nextNode.getName().startsWith("jcr")){
						rangeList.add(nextNode.getName());
					}
				}
			
		
		} catch (LoginException e) {
			log.error("Login Exception:"+e);
		} catch (RepositoryException e) {
			log.error("RepositoryException Exception:"+e);
		}
		return rangeList;
	}
	
	public static List<String> getSectionList(String range) {
		
		ResourceResolverFactory resolverFactory = getServiceReference(ResourceResolverFactory.class);
		ResourceResolver resourceResolver;
		List<String> sectionList = new ArrayList<String>();
		try {
			resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			Resource resource = resourceResolver.getResource("/etc/commerce/products/havells/"+range);
			Node node = resource.adaptTo(Node.class);
			
				NodeIterator nodeIterator = node.getNodes();
				while(nodeIterator.hasNext()) {
					Node nextNode = nodeIterator.nextNode();
					if(!nextNode.getName().startsWith("jcr")){
						sectionList.add(nextNode.getName());
					}
				}
			
		
		} catch (LoginException e) {
			log.error("Login Exception:"+e);
		} catch (RepositoryException e) {
			log.error("RepositoryException Exception:"+e);
		}
		return sectionList;
	}
}
