package com.havells.excel.importer.service.impl;

import java.util.Dictionary;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.service.component.ComponentContext;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.havells.excel.importer.service.ExcelImporterService;

@Component(immediate = true, metatype = true, label = "Excel Importer Service")
@Service(value = ExcelImporterService.class)
public class ExcelImporterServiceImpl implements ExcelImporterService {

	private static final Logger log = LoggerFactory.getLogger(ExcelImporterServiceImpl.class);

	private static final String DEFAULT_ETC_PATH="/etc/commerce/products/havells-test";
	
	private static final String DEFAULT_CONTENT_PATH="/content/havells/en/sustainability";
	private String etcPath;
	private String contentPath;
	
	@Property(value = ExcelImporterServiceImpl.DEFAULT_ETC_PATH)
	public static final String ETC_PATH = "havells.excel.importer.etc.path";
	
	@Property(value = ExcelImporterServiceImpl.DEFAULT_CONTENT_PATH)
	public static final String CONTENT_PATH = "havells.excel.importer.content.path";
	
	
	/** Activate this component. */
	protected void activate(final ComponentContext ctx) {
		log.info("Activating DigiKeyClientServiceImpl service.");
		final Dictionary<?, ?> config = ctx.getProperties();

		etcPath = PropertiesUtil.toString(config.get(ETC_PATH), DEFAULT_ETC_PATH);
		contentPath= PropertiesUtil.toString(config.get(CONTENT_PATH), DEFAULT_CONTENT_PATH);
	}

	/** Deactivate this component. */
	protected void deactivate(final ComponentContext context) {
		log.info("Deactivating DigiKeyClientServiceImpl service.");
	}

	public String getEtcPathToCreateProductsNode() {
		return etcPath;
	}

	public String getContentPathToCreatePages() {
		return contentPath;
	}

}
