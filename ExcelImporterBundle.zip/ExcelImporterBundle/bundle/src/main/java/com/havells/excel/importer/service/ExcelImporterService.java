package com.havells.excel.importer.service;

public interface ExcelImporterService {

	public String getEtcPathToCreateProductsNode() ;
	
	public String getContentPathToCreatePages();
}
