package com.havells.excel.importer.DTO;

import java.util.List;
import java.util.Map;

public class Range {
	
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String,Category> getCategories() {
		return categories;
	}

	public void setCategories( Map<String,Category> categories) {
		this.categories = categories;
	}

	private Map<String,Category> categories;
	

}
