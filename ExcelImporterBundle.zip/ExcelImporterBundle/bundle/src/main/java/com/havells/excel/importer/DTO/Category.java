package com.havells.excel.importer.DTO;

import java.util.List;
import java.util.Map;

public class Category {

	private String name;
	
	private Map<String,SubCategory> subCategories;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String,SubCategory> getSubCategories() {
		return subCategories;
	}

	public void setSubCategories(Map<String,SubCategory> subCategories) {
		this.subCategories = subCategories;
	}
}
