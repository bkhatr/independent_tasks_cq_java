package com.havells.excel.importer;

public interface ExcelImporterConstants {

	public static final int SECTION = 0;
	public static final int RANGE = 1;
	public static final int CATEGORY = 2;
	public static final int SUB_CATEGORY = 3;
	public static final int SKU_IMAGE_TITLE = 4;
	public static final int SKU_IMAGE_SUB_TITLE = 5;
	public static final int SKU_PRODUCT_NAME_LEAD = 6;
	public static final int SKU_PRODUCT_NAME_VARIANT = 7;
	public static final int SKU_PRODUCT_NAME_COLOR = 8;
	public static final int SKU_PROPERTY_ENABLE_ECOMM = 9;
	public static final int SKU_IMAGE_PATH = 10;
	public static final int SKU_PROPERTY_PRODUCT_IMAGES = 11;
	public static final int SKU_PROPERTY_360_DEGREE_IMAGE = 12;
	public static final int SKU_PROPERTY_CQ_TAGS = 13;
	public static final int SKU_PROPERTY_COLOR = 14;
	public static final int SKU_PROPERTY_COLOR_IMG = 15;
	public static final int SKU_PROPERTY_GIFT_WRAP = 16;
	public static final int SKU_PROPERTY_FAQ = 178;

	public static final int SKU_PROPERTY_PRODUCT_MANUAL = 17;
	public static final int SKU_PROPERTY_PRODUCT_BROCHURE = 18;
	public static final int SKU_PROPERTY_PRODUCT_RECOMMENDATIONS = 19;
	
	public static final int SKU_OTHER_INFO_QUICK_FEATURES_STARTING_INDEX = 20;
	public static final int SKU_OTHER_INFO_QUICK_FEATURES_ENDING_INDEX = 27;
	public static final int SKU_OTHER_INFO_QUICK_FEATURES_HEADING = 0;
	public static final int SKU_OTHER_INFO_QUICK_FEATURES_DESCTIPTION = 1;
	
	public static final int SKU_OTHER_INFO_DETAIL_FEATURES_STARTING_INDEX = 28;
	public static final int SKU_OTHER_INFO_DETAIL_FEATURES_ENDING_INDEX = 102;
	public static final int SKU_OTHER_INFO_DETAIL_FEATURES_HEADING = 0;
	public static final int SKU_OTHER_INFO_DETAIL_FEATURES_DESCRIPTION= 1;
	public static final int SKU_OTHER_INFO_DETAIL_FEATURES_IMAGE = 2;
	
	public static final int SKU_OTHER_INFO_OPTIONAL_FEATURES_STARTING_INDEX = 103;
	public static final int SKU_OTHER_INFO_OPTIONAL_FEATURES_ENDING_INDEX = 177;
	public static final int SKU_OTHER_INFO_OPTIONAL_FEATURES_HEADING = 0;
	public static final int SKU_OTHER_INFO_OPTIONAL_FEATURES_DESCRIPTION= 1;
	public static final int SKU_OTHER_INFO_OPTIONAL_FEATURES_IMAGE = 2;
	
	public static final int SKU_OTHER_INFO_TECHNICAL_SPEC_STARTING_INDEX = 179;
	public static final int SKU_OTHER_INFO_TECHNICAL_SPEC_ENDING_INDEX = 373;
	public static final int SKU_OTHER_INFO_TECHNICAL_SPEC_CQ_TAGS = 0;
	public static final int SKU_OTHER_INFO_TECHNICAL_SPEC_KEY = 1;
	public static final int SKU_OTHER_INFO_TECHNICAL_SPEC_VALUE = 2;

	public static final int SKU_OTHER_INFO_TECHNICAL_SPEC_IMAGE_PROPERTY = 374;
	
	public static final int SKU_OTHER_INFO_ACCESSORY_STARTING_INDEX = 375;
	public static final int SKU_OTHER_INFO_ACCESSORY_ENDING_INDEX = 434;
	public static final int SKU_OTHER_INFO_ACCESSORY_HEADING = 0;
	public static final int SKU_OTHER_INFO_ACCESSORY_DESCRIPTION = 1;
	public static final int SKU_OTHER_INFO_ACCESSORY_IMAGE = 2;
	
	public static final int SKU_OTHER_INFO_TECHNICAL_DRAWING_IMAGES = 435;
	
	public static final int SKU_OTHER_INFO_YOU_TUBE_URLS = 436;
	
	public static final String FOLDER_THUMBNAIL_BG_COLOR_PROPERTY = "bgcolor";
	
	public static final String FOLDER_THUMBNAIL_DAM_DESCRIPTIONS = "dam:descriptions";
	
	public static final String FOLDER_THUMBNAIL_DAM_PATHS = "dam:folderThumbnailPaths";
	
	public static final String FOLDER_THUMBNAIL_WIDTH = "width";
	
	public static final String FOLDER_THUMBNAIL_HEIGHT = "height";
	
	public static final String IMAGE_FILE_REFERENCE_PROPERTY = "fileReference";
	
	public static final String SLING_RESOURCE_TYPE_PROPERTY = "sling:resourceType";
	
	public static final String HEADER_PROPERTY_PREFIX = "heading";
	
	public static final String DESCRIPTION_PROPERTY_PREFIX = "description";
	
	public static final String IMAGE_PROPERTY_PREFIX = "image";
	
	public static final String IMAGES_PROPERTY = "images";
	
	public static final String CQ_TAGS_PROPERTY= "cq:Tags";
	
	public static final String KEY_PROPERTY = "key";
	
	public static final String VALUE_PROPERTY = "value";
	
	public static final String DRAWING_IMAGES_PROPERTY = "drawingImages";
	
	public static final String QUICK_FEATURES_NODE = "quickFeatures";
	
	public static final String DETAIL_FEATURES_NODE = "detailFeatures";
	
	public static final String OPTIONAL_FEATURES_NODE = "optionalFeatures";
	
	public static final String TECHNICAL_SPEC_NODE = "technicalSpec";
	
	public static final String TECHNICAL_DRAWING_IMAGES ="technicalDrawing";
	
	public static final String ACCESSORY_NODE = "accessory";	
	public static final String CQ_COMMERECE_PROVIDER_PROPERTY = "cq:commerceProvider";
	
	public static final String CQ_TEMPLATE_PROPERTY = "cq:template";	
	public static final String CONTENT_TEMPLATE = "/apps/havells/templates/content-template";
	
	public static final String CONTENT_COMPONENT = "/apps/havells/components/page/havells-content";	
	public static final String TOP_BANNER_COMPONENT="havells/components/content/topbanner";
	
	public static final String TOP_BANNER_NODE_NAME="topbanner";	
	public static final String SORT_PRODUCTS_COMPONENT ="havells/components/content/sortproducts";
	
	public static final String SORT_PRODUCTS_NODE_NAME ="sortproducts";	
	public static final String SEARCH_CONTAINER_COMPONENT="havells/components/common/filterSearch/searchContainer";
	
	public static final String SEARCH_CONTAINER_NODE_NAME="searchcontainer";	
	public static final String SEARCH_PAR_NODE_NAME="searchPar";
	
	public static final String PRODUCT_DETAILS_GRID_COMPONENT="havells/components/content/productdetailsgrid";	
	public static final String PRODUCT_DETAILS_GRID_NODE_NAME="productdetailsgrid";
	
	public static final String CONNECT_COMPONENT="havells/components/content/connect";	
	public static final String CONNECT_NODE_NAME="connect";
	
	public static final String RELATED_PRODUCTS_NAME = "relatedproducts";	
	public static final String RELATED_PRODUCTS_COMPONENT="havells/components/content/relatedproducts";
	
	public static final String TOP_NAVIGATION_NODE_NAME = "topnavigation";
	public static final String TOP_NAVIGATION_COMPONENT="havells/components/content/topnavigation";
	
	public static final String PRODUCT_SUB_CATEGORY_NODE_NAME = "productsubcategory";
	public static final String PRODUCT_SUB_CATEGORY_COMPONENT="havells/components/content/productsubcategory";

	public static final String PRODUCT_CATEGORY_NODE_NAME="productcategory";
	public static final String PRODUCT_CATEGORY_COMPONENT="havells/components/content/productcategory";
	
	public static final String MID_BANNER_NODE_NAME = "midbanner";
	public static final String MID_BANNER_COMPONENT="havells/components/content/midbanner";

	public static final String COLUMN_VIDEO_COMPONENT = "havells/components/content/columnvideo";
	public static final String COLUMN_VIDEO_NODE_NAME="columnvideo";

	public static final String NEWS_NODE_NAME= "news";
	public static final String NEWS_COMPONENT="havells/components/content/news";

	public static final String MAIN_NAV_NODE_NAME ="main_nav";
	public static final String MAIN_NAV_COMPONENT_NAME="havells/components/content/main-nav";
	
	public static final String PRODUCT_GRID_NODE_NAME="productgrid";
	public static final String PRODUCT_GRID_COMPONENT="havells/components/content/productgrid";
	
	public static final String CATEGORY_COLUMN_VIDEO_NODE_NAME="categorycolumnvideo";
	public static final String CATEGORY_COLUMN_VIDEO_COMPONENT="havells/components/content/categorycolumnvideo";
	
	public static final String TAG_PREFIX = "havells:product_tech_specification";

}
